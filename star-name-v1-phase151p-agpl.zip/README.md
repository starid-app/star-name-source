# Current Phase149P status

Pinned GeoNames named-place resolution and IANA 2026e civil-time conversion are implemented. P1-A and P2-B are frozen. Hospital coordinates are unnecessary; city representative-point provenance is explicit. Normal private input resolves city/time, while product chart activation remains off at the inherited E4 rights/admission certificate. All downstream positive paths remain disabled. See docs/M3_149P_OPERATIONS.md and top-level Phase149P policies for the controlling current behavior.

The following inherited notes are retained as historical implementation context; where they describe absent E1/place/time resources or unfrozen P1/P2, the current Phase149P locks and operations note supersede them.

# Phase148P E1 restoration

Read [M3 E1 restoration](docs/M3_E1_RESTORATION.md). The historical numerical resources are restored; P1/P2 and place/civil-time authority still prevent product chart activation. All positive downstream paths remain disabled. The following descriptions record earlier milestones.

# Phase144P M2 update

Read [M2 operations](docs/M2_OPERATIONS.md) for the current runtime, encryption, redaction and test instructions. The original M0/M1 description below records the inherited baseline; M2 adds forward migration 0002 and retains its exact non-result. Production startup and all positive numerical/canonical paths remain disabled.

# Star Name v1 — private M0/M1 prototype

This runnable slice accepts private exact birth input, pins immutable governance, queues a durable job and persists `INPUT / CHART UNRESOLVED`. There is no approved place/civil-time or numerical bundle. No canonical name, identity or StarID is issued. This is a symbolic-methodology prototype, with no scientific or causal outcome claim.

## Local setup (Python 3.12; Node 20.19+ or 22.12+)

Run from this directory:

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.lock
.venv/bin/python scripts/dev_setup.py
set -a
. ./.env
set +a
.venv/bin/alembic upgrade head
cd web
npm ci
npm run build
cd ..
.venv/bin/uvicorn api.asgi:app --host 127.0.0.1 --port 8000 --no-access-log
```

In a second terminal, load the same private environment and run the durable worker:

```bash
set -a
. ./.env
set +a
.venv/bin/python -m worker.main
```

Open http://127.0.0.1:8000. Enter the token portion of `DEV_TOKENS` from your own `.env` (before `:local-owner`). Credentials are generated locally; no fixed credential ships. The client keeps the credential only in memory. After a browser reload, sign in again and open private history to retrieve the unchanged result.

For separate hot-reloading client development, keep API at port 8000 and run:

```bash
cd web
npm run dev
```

Vite proxies `/v1` to the local API. Do not expose the development sign-in publicly. HTTPS/session/OIDC production integration is deferred and production startup is deliberately refused.

## Migration/seed and tests

`alembic upgrade head` creates the schema, append-only triggers, all 15 exact inherited terminal rows and the all-disabled release snapshot. Never use `create_all` directly for application startup. Downgrade refuses destructive historical deletion.

```bash
.venv/bin/pytest -q --junitxml=pytest.xml
.venv/bin/python -m worker.main --once
cd web
npm run build
```

Worker `--once` processes one queued job through exactly the same transaction/domain path as the continuous worker. A crash before commit rolls back and leaves the durable job queued. A final transaction inserts outcome, stages, audit and one private status outbox event together. Duplicate delivery sees the immutable existing outcome. The outbox is a durable internal status ledger; no notification/send transport is activated.

## PostgreSQL / development containers

```bash
docker compose up --build
```

Generate `.env` first using the local setup above. Compose starts private PostgreSQL, migrations, API/static client and worker. It overrides DATABASE_URL to the private PostgreSQL service. Images have version tags, not verified image digests: pin verified images before any deployment. Container/PostgreSQL runtime acceptance was not executed in this environment; see reports. SQLite is an explicit development-only adapter, not production semantics. Both dialects have relational ownership/uniqueness constraints and append-only triggers. PostgreSQL jobs use `FOR UPDATE SKIP LOCKED`; development SQLite serializes short worker transactions using `BEGIN IMMEDIATE`.

## API implemented

Authenticated bearer development tokens map to owner principals on the server. All `/v1` reads/writes are owner-scoped, unknown IDs and foreign-owned IDs return uniform 404. Private responses use `Cache-Control: no-store`.

- `POST /v1/birth-inputs` accepts local_date, local_time, time_precision=`exact`, place_query_or_selected_ref, consent_version=`M1-private-v1`.
- `GET /v1/birth-inputs` and `GET /v1/birth-inputs/{id}` read only owned inputs.
- `POST /v1/determinations` accepts only birth_input_id; required `Idempotency-Key` returns the same run on retry, conflicting body returns 409.
- `GET /v1/determinations/{id}` returns delivery status, exact terminal/reasons, stages and pinned versions.
- `GET /v1/history?limit=50&cursor=<owned-run-id>` returns descending stable owner history.
- `/canonical` and `/starid` verify ownership then return 409 without issued data.

Common success envelope: schema_version, request_id, data. Input validation rejects unknown fields. Client authority flags, chart IDs, preference fields and owner spoofing are unsupported. All other Phase142P endpoints remain unavailable in M0/M1. Interactive schema is at `/docs`.

Birth JSON is encrypted with a server-held Fernet key; no birth values go into audit, job payload, logs, URLs or browser storage. Do not lose the vault key. This local single-key adapter is an engineering substitution for a future managed owner vault; rotation, deletion, retention/backup rehearsal and production auth are not certified here.

Input creation always inserts an immutable revision. There is no edit API in M1; a correction is a new input and new determination. Historical outcomes and snapshots are append-only. Opaque run/input UUIDs are storage references, never canonical identity identifiers.

## Governance and trace

`governance/terminals.csv` is byte-authenticated from Phase141P; `capabilities.json` is a frozen all-disabled Phase143P manifest. Compiled expected hashes reject tampering; environment/client inputs never activate paths. A worker verifies the pinned release digest and its exact expected current build snapshot. Unavailable historical execution is an operational limitation and cannot rewrite outcomes.

Stage 0 is version lock. Stage 1 evaluates approved input/strict-chart prerequisites and stops because approved place/civil-time resources are absent. Stage 2 strict numerical calculation and stages 3–30 are `NOT_EXECUTED`. Additional numerical blockers are recorded with evaluated=false. No successful civil-time interpretation, chart, target or concept is fabricated. Structural date/time validation is transport validation only.

The source boundaries are `web`, `api`, `worker`, `determination`, `persistence`, and `governance`. The client imports no engine code. Pure chart guard accepts only a server release snapshot. There are no positive numerical/semantic/issuance executors in this build.

## Optional browser smoke (not executed here)

After API and continuous worker are running, supply a private development token in `UI_DEV_TOKEN` and run:

```bash
cd web
npx playwright install chromium
npm run test:browser
```

The fresh browser script exercises a mobile form, exact STOP, refresh, history, reauthentication after reload and overflow/page-error checks. Chromium installation returned empty/truncated downloads in this executor, so this script is supplied without a browser PASS claim.
