from sqlalchemy import create_engine,event
from sqlalchemy.orm import sessionmaker
from cryptography.fernet import Fernet
class Store:
    def __init__(self,settings):
        settings.__post_init__()
        self.engine=create_engine(settings.database_url,hide_parameters=True,pool_pre_ping=True,connect_args={'check_same_thread':False} if settings.database_url.startswith('sqlite') else {})
        if self.engine.dialect.name=='sqlite':
            @event.listens_for(self.engine,'connect')
            def configure(dbapi,record):
                dbapi.execute('PRAGMA foreign_keys=ON')
                dbapi.execute('PRAGMA busy_timeout=10000')
        self.session=sessionmaker(self.engine,expire_on_commit=False)
        self.key_version=settings.key_version
        self.keys={v:Fernet(k.encode()) for v,k in (settings.vault_keys or {settings.key_version:settings.vault_key}).items()}
        self.vault=self.keys[self.key_version]
    def decrypt(self,entry):
        return self.keys[entry.key_version].decrypt(entry.ciphertext.encode())
