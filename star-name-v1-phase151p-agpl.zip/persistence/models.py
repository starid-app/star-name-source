from sqlalchemy import Column,String,Integer,Text,ForeignKey,UniqueConstraint,CheckConstraint,ForeignKeyConstraint,event
from sqlalchemy.orm import declarative_base
Base=declarative_base()
class Account(Base):
    __tablename__='accounts'
    id=Column(String,primary_key=True)
class Redaction(Base):
    __tablename__='account_redactions'
    owner_id=Column(String,ForeignKey('accounts.id'),primary_key=True)
    created_at=Column(String,nullable=False)
class VaultEntry(Base):
    __tablename__='birth_vault'
    birth_id=Column(String,ForeignKey('birth_inputs.id'),primary_key=True)
    ciphertext=Column(Text,nullable=False)
    key_version=Column(String,nullable=False)
class BirthInput(Base):
    __tablename__='birth_inputs'
    id=Column(String,primary_key=True)
    owner_id=Column(String,ForeignKey('accounts.id'),nullable=False)
    logical_id=Column(String,nullable=False)
    revision=Column(Integer,nullable=False)
    predecessor_id=Column(String,ForeignKey('birth_inputs.id'))
    encrypted=Column(Text,nullable=False)
    created_at=Column(String,nullable=False)
    __table_args__=(UniqueConstraint('owner_id','logical_id','revision'),UniqueConstraint('id','owner_id'),CheckConstraint('revision > 0'))
class TerminalState(Base):
    __tablename__='terminal_states'
    id=Column(String,primary_key=True)
    payload=Column(Text,nullable=False)
class Release(Base):
    __tablename__='releases'
    id=Column(String,primary_key=True)
    payload=Column(Text,nullable=False)
class Run(Base):
    __tablename__='runs'
    id=Column(String,primary_key=True)
    owner_id=Column(String,ForeignKey('accounts.id'),nullable=False)
    birth_id=Column(String,nullable=False)
    release_id=Column(String,ForeignKey('releases.id'),nullable=False)
    key_hash=Column(String,nullable=False)
    request_digest=Column(String,nullable=False)
    created_at=Column(String,nullable=False)
    __table_args__=(UniqueConstraint('owner_id','key_hash'),ForeignKeyConstraint(['birth_id','owner_id'],['birth_inputs.id','birth_inputs.owner_id']))
class Outcome(Base):
    __tablename__='outcomes'
    run_id=Column(String,ForeignKey('runs.id'),primary_key=True)
    payload=Column(Text,nullable=False)
class Stage(Base):
    __tablename__='stages'
    id=Column(String,primary_key=True)
    run_id=Column(String,ForeignKey('runs.id'),nullable=False)
    ordinal=Column(Integer,nullable=False)
    payload=Column(Text,nullable=False)
    __table_args__=(UniqueConstraint('run_id','ordinal'),)
class Audit(Base):
    __tablename__='audit_events'
    id=Column(String,primary_key=True)
    object_id=Column(String,nullable=False)
    action=Column(String,nullable=False)
    created_at=Column(String,nullable=False)
    __table_args__=(UniqueConstraint('object_id','action',name='uq_audit_semantic_event'),)
class Job(Base):
    __tablename__='jobs'
    id=Column(String,primary_key=True)
    run_id=Column(String,ForeignKey('runs.id'),unique=True,nullable=False)
    state=Column(String,nullable=False)
    attempts=Column(Integer,nullable=False,default=0)
    __table_args__=(CheckConstraint("state IN ('QUEUED','FINALIZED')"),)
class Outbox(Base):
    __tablename__='outbox'
    id=Column(String,primary_key=True)
    run_id=Column(String,ForeignKey('runs.id'),unique=True,nullable=False)
    kind=Column(String,nullable=False)
for model in [BirthInput,TerminalState,Release,Run,Outcome,Stage,Audit,Outbox,Redaction]:
    def reject(*args): raise ValueError('Append-only record')
    event.listen(model,'before_update',reject)
    event.listen(model,'before_delete',reject)

class ChartProvenanceVault(Base):
    __tablename__='chart_provenance_vault'
    run_id=Column(String,ForeignKey('runs.id'),primary_key=True)
    ciphertext=Column(Text,nullable=False)
    key_version=Column(String,nullable=False)
