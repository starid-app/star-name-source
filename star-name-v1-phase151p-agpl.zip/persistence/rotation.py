"""Operator-only, bounded re-encryption. No API capability to supply keys."""
from sqlalchemy import select,text
from persistence.models import VaultEntry,Audit,ChartProvenanceVault
def rotate_batch(store,limit=100):
    if not 1 <= limit <= 1000: raise ValueError('Invalid batch size')
    with store.session() as s:
        if store.engine.dialect.name=='sqlite': s.execute(text('BEGIN IMMEDIATE'))
        entries=list(s.scalars(select(VaultEntry).where(VaultEntry.key_version!=store.key_version).order_by(VaultEntry.birth_id).limit(limit).with_for_update(skip_locked=True)))
        for entry in entries:
            entry.ciphertext=store.vault.encrypt(store.decrypt(entry)).decode()
            entry.key_version=store.key_version
            from worker.jobs import uid,now
            s.add(Audit(id=uid(),object_id=entry.birth_id,action="VAULT_REENCRYPTED_"+store.key_version,created_at=now()))
        remaining=limit-len(entries)
        provenance=list(s.scalars(select(ChartProvenanceVault).where(ChartProvenanceVault.key_version!=store.key_version).order_by(ChartProvenanceVault.run_id).limit(remaining).with_for_update(skip_locked=True))) if remaining else []
        for entry in provenance:
            entry.ciphertext=store.vault.encrypt(store.decrypt(entry)).decode()
            entry.key_version=store.key_version
        s.commit()
        return len(entries)+len(provenance)
