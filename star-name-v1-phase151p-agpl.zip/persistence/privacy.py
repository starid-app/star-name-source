"""Operator restore gate: reapply independently retained deletion tombstones before exposure.
Ledger owner IDs are private opaque refs, never published. Infrastructure must retain a
current ledger outside older database backups; this module does not provision storage.
"""
from sqlalchemy import select,delete,text
from persistence.models import Account,BirthInput,VaultEntry,Redaction,Audit,Run,ChartProvenanceVault
from worker.jobs import uid,now

def export_tombstones(store):
    with store.session() as s:
        return [{'owner_id':r.owner_id,'created_at':r.created_at} for r in s.scalars(select(Redaction).order_by(Redaction.owner_id))]

def reapply_tombstones(store,ledger):
    with store.session() as s:
        if store.engine.dialect.name=='sqlite':s.execute(text('BEGIN IMMEDIATE'))
        for item in sorted(ledger,key=lambda x:x['owner_id']):
            owner=item['owner_id']
            account=s.scalar(select(Account).where(Account.id==owner).with_for_update())
            if not account:continue
            s.execute(delete(VaultEntry).where(VaultEntry.birth_id.in_(select(BirthInput.id).where(BirthInput.owner_id==owner))))
            s.execute(delete(ChartProvenanceVault).where(ChartProvenanceVault.run_id.in_(select(Run.id).where(Run.owner_id==owner))))
            if not s.get(Redaction,owner):
                s.add(Redaction(owner_id=owner,created_at=item['created_at']))
                s.add(Audit(id=uid(),object_id=owner,action='ACCOUNT_PRIVATE_DATA_REDACTED',created_at=now()))
        s.commit()
