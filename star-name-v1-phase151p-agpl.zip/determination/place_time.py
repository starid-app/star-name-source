"""Finite authenticated GeoNames/IANA transformations; no host-zone lookup."""
import hashlib,json,re,unicodedata
from pathlib import Path
from decimal import Decimal
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
from io import BytesIO
ROOT=Path(__file__).resolve().parents[1]
PLACE_LOCK_SHA256='70405bb8c89d53583aa9dc62b480000ebf548e28a1fe44bc04255791f0d967a3'
TIME_LOCK_SHA256='bd9c2c6b01e8e997e378f8e3bef5b0fb8e51a24b2bf74a2a772189c7907c360c'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def checked_bytes(path,expected):
    if path.is_symlink():raise ValueError('AUTHORITY_SYMLINK_REJECTED')
    raw=path.read_bytes()
    if digest(raw)!=expected:raise ValueError('AUTHORITY_HASH_MISMATCH')
    return raw

def locks():
    return (json.loads(checked_bytes(ROOT/'governance/PLACE_AUTHORITY_LOCK.json',PLACE_LOCK_SHA256)),json.loads(checked_bytes(ROOT/'governance/CIVIL_TIME_AUTHORITY_LOCK.json',TIME_LOCK_SHA256)))
def norm(s):return ' '.join(unicodedata.normalize('NFC',s).casefold().split())
def candidates(query,records):
    if not isinstance(query,str):return [],'PLACE_INPUT_INVALID'
    query=query.strip()
    if re.fullmatch(r'geonames:[0-9]+',query):
        found=[r for r in records if r['id']==query]
        return found,None if found else 'PLACE_UNSUPPORTED'
    parts=[norm(x) for x in query.split(',')]
    if len(parts) not in (3,4) or not all(parts):return [],'PLACE_SPECIFICATION_INSUFFICIENT'
    found=[r for r in records if parts[0] in {norm(r['name']),norm(r['ascii_name'])} and parts[-2] in {norm(r['admin1_name']),norm(r['admin1_ascii']),norm(r['admin1_code'])} and parts[-1] in {norm(r['country_name']),norm(r['country_code'])}]
    if len(parts)==4:found=[r for r in found if parts[1] in {norm(r.get('admin2_name') or ''),norm(r.get('admin2_code') or '')}]
    return found,('PLACE_AMBIGUOUS' if len(found)>1 else 'PLACE_UNSUPPORTED' if not found else None)
def resolve_place(query):
    p,t=locks();registry=json.loads(checked_bytes(ROOT/p['dataset_path'],p['dataset_sha256']))
    found,reason=candidates(query,registry['records'])
    if reason:return {'status':'UNRESOLVED','reason':reason,'candidate_ids':sorted(r['id'] for r in found)}
    r=dict(found[0]);zone=r['timezone_identifier']
    if zone not in t['tzif_sha256']:return {'status':'UNRESOLVED','reason':'TIMEZONE_MAPPING_UNSUPPORTED'}
    r.update(status='RESOLVED',reason=None,provider=p['provider'],dataset_version=p['dataset_version'],dataset_sha256=p['dataset_sha256'],authority_lock_sha256=PLACE_LOCK_SHA256,latitude_e7=int(Decimal(r['latitude'])*10_000_000),longitude_e7=int(Decimal(r['longitude'])*10_000_000))
    return r
def parse_local(input):
    if input.get('time_precision')!='exact':raise ValueError('INPUT_PRECISION_INSUFFICIENT')
    d=input.get('local_date');t=input.get('local_time')
    if not isinstance(d,str) or not isinstance(t,str):raise ValueError('CIVIL_INPUT_INVALID')
    if re.search(r'(Z|[+-]\d\d:?\d\d)$',t):raise ValueError('LOCAL_CIVIL_TIME_REQUIRED')
    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',d) or not re.fullmatch(r'\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?',t):raise ValueError('CIVIL_INPUT_INVALID')
    try:local=datetime.fromisoformat(d+'T'+t)
    except ValueError as exc:raise ValueError('CIVIL_INPUT_INVALID') from exc
    if not 1800<=local.year<=2399:raise ValueError('EPHEMERIS_DATE_OUT_OF_RANGE')
    fold=input.get('civil_fold')
    if fold is not None and (type(fold) is not int or fold not in (0,1)):raise ValueError('CIVIL_FOLD_INVALID')
    return local,fold

def interpret_local(local,zone,requested_fold,start,end):
    valid={}
    for f in (0,1):
        utc=local.replace(tzinfo=zone,fold=f).astimezone(timezone.utc);back=utc.astimezone(zone)
        if back.replace(tzinfo=None)==local:valid[utc]=(back.fold,int(back.utcoffset().total_seconds()))
    if not valid:raise ValueError('DST_GAP')
    if len(valid)>1 and requested_fold is None:raise ValueError('DST_FOLD')
    selected=[(u,f,o) for u,(f,o) in valid.items() if requested_fold is None or f==requested_fold]
    if len(selected)!=1:raise ValueError('CIVIL_FOLD_INCONSISTENT')
    utc,f,offset=selected[0]
    if not start<=utc<end:raise ValueError('TIMEZONE_HISTORY_UNSUPPORTED')
    return utc,f,offset

def resolve_time(input,place):
    try:
        local,fold=parse_local(input)
        if place.get('status')!='RESOLVED':return {'status':'UNRESOLVED','reason':'PLACE_NOT_ADMITTED'}
        p,t=locks();identifier=place['timezone_identifier'];expected=t['tzif_sha256'].get(identifier)
        if expected is None:raise ValueError('TIMEZONE_MAPPING_UNSUPPORTED')
        raw=checked_bytes(ROOT/t['dataset_path']/identifier,expected);zone=ZoneInfo.from_file(BytesIO(raw),key=identifier)
        start=datetime.fromisoformat(t['supported_utc_start'].replace('Z','+00:00'));end=datetime.fromisoformat(t['supported_utc_end_exclusive'].replace('Z','+00:00'))
        if local.year<1970 or local.year>2026:raise ValueError('TIMEZONE_HISTORY_UNSUPPORTED')
        utc,selected,offset=interpret_local(local,zone,fold,start,end)
        return {'status':'RESOLVED','reason':None,'utc_instant':utc.isoformat(timespec='microseconds').replace('+00:00','Z'),'timezone_identifier':identifier,'dataset_version':t['dataset_version'],'dataset_sha256':t['archive_sha256'],'tzif_sha256':expected,'authority_lock_sha256':TIME_LOCK_SHA256,'historical_offset_seconds':offset,'fold':selected,'requested_fold':fold,'fold_provenance':'USER_EXPLICIT' if fold is not None else 'UNIQUE_INSTANT','precision':'exact','calendar':'PROLEPTIC_GREGORIAN','local_civil':local.isoformat(timespec='microseconds'),'supported_utc_interval':[t['supported_utc_start'],t['supported_utc_end_exclusive']]}
    except (ValueError,OSError,KeyError) as exc:return {'status':'UNRESOLVED','reason':str(exc),'utc_instant':None}
