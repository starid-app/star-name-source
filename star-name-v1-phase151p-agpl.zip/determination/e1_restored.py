"""E1 custody and isolated regression. No place/time input admission path."""
import hashlib
from importlib import metadata
from pathlib import Path
from threading import RLock
from datetime import timezone
EPHE_DIR=Path(__file__).resolve().parents[1]/'resources/ephe'
HASHES={'sepl_18.se1':'ca1393ceab3a44fbc895887cf789c68819ae6a1cbc9b22225872dbe4ccd99a66','semo_18.se1':'1ca07bd67c24374d77226180c20a4f9996cba013697894810518e7eb582ca4f7'}
_NUMERICAL_LOCK=RLock()
def runtime_identity():
    try:
        import swisseph as swe
        package=metadata.version('pyswisseph')
        return {'compatible':package=='2.10.3.2' and str(swe.version)=='2.10.03','package':package,'backend':str(swe.version),'current_binary_sha256':hashlib.sha256(Path(swe.__file__).read_bytes()).hexdigest(),'historical_binary_sha256':None,'identity_scope':'current compatible build, not recovered original binary'}
    except (ImportError,metadata.PackageNotFoundError,OSError):
        return {'compatible':False,'package':None,'backend':None,'current_binary_sha256':None,'historical_binary_sha256':None,'identity_scope':'compatible runtime unavailable'}
def strict_resource_preflight(directory=EPHE_DIR):
    directory=Path(directory)
    for name,expected in HASHES.items():
        p=directory/name
        if p.is_symlink():raise ValueError('EPHEMERIS_STRICT_FAILURE: symlink')
        try:raw=p.read_bytes()
        except OSError as exc:raise ValueError('EPHEMERIS_STRICT_FAILURE: missing resource') from exc
        if hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('EPHEMERIS_STRICT_FAILURE: hash mismatch')
    return dict(HASHES)
def require_runtime():
    result=runtime_identity()
    if not result['compatible']:raise ValueError('EPHEMERIS_STRICT_FAILURE: runtime identity')
    return result
def historical_numerical_regression(validated,*,directory=EPHE_DIR):
    """Authenticated UTC/coordinate fixture replay; never called by worker/adapter."""
    with _NUMERICAL_LOCK:
        strict_resource_preflight(directory);require_runtime()
        if validated.utc_datetime.tzinfo is None:raise ValueError('INPUT / CHART UNRESOLVED: aware UTC instant required')
        if not 1800<=validated.utc_datetime.astimezone(timezone.utc).year<=2399:raise ValueError('EPHEMERIS_DATE_OUT_OF_RANGE')
        from determination.historical_rc3.astro.swiss import calculate_chart
        import swisseph as swe
        original=swe.calc_ut
        def checked_calc(*args):
            values,flags=original(*args)
            if flags<0 or flags & 7 != 2:
                # Let unchanged RC3 strict returned-mode path map fallback to its frozen state.
                flags=4
            return values,flags
        swe.calc_ut=checked_calc
        try:return calculate_chart(validated,ephemeris_path=str(directory),strict_swiss_ephemeris=True)
        finally:swe.calc_ut=original
