"""Place/time authority-blocked M3. Authenticated E1 resources restored; no host timezone.
Low-level numerical diagnostics are not admission and cannot produce product charts.
"""
import hashlib,json
from dataclasses import dataclass,asdict
from datetime import date,datetime
from pathlib import Path
from typing import Protocol

LOCK_PATH=Path(__file__).resolve().parents[1]/'governance/M3_NUMERICAL_AUTHORITY_LOCK.json'
EXPECTED_LOCK_SHA256='7f69286fa0d56950e3117d558a6ac8f7404a4b165d7d644c04d9eac30ce005ff'

def authority_lock():
    raw=LOCK_PATH.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=EXPECTED_LOCK_SHA256:
        raise RuntimeError('M3 authority lock integrity failure')
    return json.loads(raw)

@dataclass(frozen=True)
class ResolvedPlace:
    resolved_place_id:str|None=None
    canonical_label:str|None=None
    latitude:str|None=None
    longitude:str|None=None
    provider:str|None=None
    dataset_version:str|None=None
    provenance:str|None=None
    precision:str|None=None
    timezone_identifier:str|None=None
    status:str='UNRESOLVED'
    reason:str|None='PLACE_AUTHORITY_ABSENT'
    record:dict|None=None

class PlaceResolver(Protocol):
    def resolve(self,place_ref:str)->ResolvedPlace: ...

class FrozenPlaceResolver:
    def resolve(self,place_ref:str)->ResolvedPlace:
        authority_lock()
        from determination.place_time import resolve_place
        try:r=resolve_place(place_ref)
        except (OSError,ValueError,KeyError) as exc:return ResolvedPlace(reason='PLACE_AUTHORITY_INTEGRITY_FAILURE',record={'error':str(exc)})
        if r['status']!='RESOLVED':return ResolvedPlace(reason=r['reason'],record=r)
        return ResolvedPlace(resolved_place_id=r['id'],canonical_label=', '.join([r['name'],r['admin1_name'],r['country_name']]),latitude=r['latitude'],longitude=r['longitude'],provider=r['provider'],dataset_version=r['dataset_version'],provenance=r['provenance'],precision='SOURCE_DECIMAL_LOCALITY_REPRESENTATIVE',timezone_identifier=r['timezone_identifier'],status='RESOLVED',reason=None,record=r)

@dataclass(frozen=True)
class CivilTimeResolution:
    utc_instant:str|None=None
    timezone_identifier:str|None=None
    dataset_version:str|None=None
    dataset_sha256:str|None=None
    historical_offset_seconds:int|None=None
    fold:int|None=None
    precision:str|None=None
    status:str='UNRESOLVED'
    reason:str|None='TIMEZONE_AUTHORITY_ABSENT'
    record:dict|None=None

class CivilTimeResolver(Protocol):
    def resolve(self,input:dict,place:ResolvedPlace)->CivilTimeResolution: ...

class FrozenCivilTimeResolver:
    def resolve(self,input:dict,place:ResolvedPlace)->CivilTimeResolution:
        authority_lock()
        from determination.place_time import resolve_time
        r=resolve_time(input,place.record or {})
        return CivilTimeResolution(**{k:v for k,v in r.items() if k in CivilTimeResolution.__dataclass_fields__ and k!='record'},record=r)

@dataclass(frozen=True)
class Preflight:
    ready:bool
    reasons:tuple[str,...]
    resource_hashes:tuple[tuple[str,str],...]=()

def verify_file(path:Path,expected_sha256:str|None)->str|None:
    """Byte verification only; caller-supplied digest never confers authority."""
    if not expected_sha256 or len(expected_sha256)!=64:
        return 'EXACT_RESOURCE_HASH_ABSENT'
    if path.is_symlink():return 'RESOURCE_SYMLINK_REJECTED'
    try: raw=path.read_bytes()
    except OSError:return 'RESOURCE_MISSING_OR_UNREADABLE'
    if hashlib.sha256(raw).hexdigest()!=expected_sha256:return 'RESOURCE_HASH_MISMATCH'
    return None

def reject_returned_flags(returned:int,swieph_bit:int,moseph_bit:int,required_mask:int)->None:
    """Diagnostic mask validator. Bit values must come from future frozen authority."""
    if returned<0 or returned&moseph_bit or not returned&swieph_bit or returned&required_mask!=required_mask:
        raise ValueError('EPHEMERIS_STRICT_FAILURE')

def preflight(resource_dir:Path|None=None,runtime_path:Path|None=None,year:int|None=None)->Preflight:
    lock=authority_lock()
    reasons=list(lock['missing_authority_objects'])
    if year is not None and not 1800<=year<=2399:reasons.append('EPHEMERIS_DATE_OUT_OF_RANGE')
    hashes=[]
    directory=resource_dir or Path(__file__).resolve().parents[1]/'resources/ephe'
    for filename,identity in lock['exact_resource_identities'].items():
        reason=verify_file(directory/filename,identity)
        if reason:reasons.append(filename+':'+reason)
        else:hashes.append((filename,identity))
    from determination.e1_restored import runtime_identity
    identity=runtime_identity()
    if not identity['compatible']:reasons.append('SWISS_RUNTIME_NOT_AUTHENTICATED')
    from determination.place_time import locks,checked_bytes,ROOT
    try:
        place_lock,time_lock=locks()
        checked_bytes(ROOT/place_lock['dataset_path'],place_lock['dataset_sha256'])
        for name,digest in time_lock['tzif_sha256'].items():checked_bytes(ROOT/time_lock['dataset_path']/name,digest)
    except (OSError,ValueError,KeyError):reasons.append('PLACE_TIME_AUTHORITY_INTEGRITY_FAILURE')
    return Preflight(bool(lock['activation']) and not reasons,tuple(reasons),tuple(hashes))

def place_time_numerical_replay(input:dict)->dict:
    """Explicit integration diagnostic, never product admission or E4 approval.
    Re-resolve original input under pinned authority; caller resolutions cannot confer it.
    """
    from determination.e1_restored import historical_numerical_regression,_NUMERICAL_LOCK
    from determination.historical_rc3.astro.models import ValidatedBirthInput
    from determination.historical_rc3.serialization import canonical_json
    from datetime import timezone
    from determination.place_time import parse_local
    place=FrozenPlaceResolver().resolve(input.get('place_query_or_selected_ref',''))
    civil=FrozenCivilTimeResolver().resolve(input,place)
    if place.status!='RESOLVED' or civil.status!='RESOLVED':raise ValueError('INPUT / CHART UNRESOLVED')
    local,_=parse_local(input);utc=datetime.fromisoformat(civil.utc_instant.replace('Z','+00:00'))
    offset=civil.historical_offset_seconds
    if offset%60:raise ValueError('CIVIL_OFFSET_REPRESENTATION_UNSUPPORTED')
    validated=ValidatedBirthInput(local,place.timezone_identifier,utc,offset//60,civil.fold,place.record['latitude_e7'],place.record['longitude_e7'])
    import swisseph as swe
    flags=[]
    with _NUMERICAL_LOCK:
        original=swe.calc_ut
        def traced(*args):
            values,returned=original(*args);flags.append({'body_id':args[1],'requested':args[2],'returned':returned});return values,returned
        swe.calc_ut=traced
        try:chart=historical_numerical_regression(validated)
        finally:swe.calc_ut=original
    payload=asdict(chart)
    payload['validated_birth']['local_datetime']=local.isoformat(timespec='microseconds')
    return {'diagnostic_only':True,'product_activation':False,'place':asdict(place),'civil_time':asdict(civil),'requested_returned_flags':flags,'chart':json.loads(canonical_json(payload)),'chart_fingerprint':chart.chart_fingerprint}

class NumericalChartAdapter:
    def calculate(self,resolved_time:CivilTimeResolution,place:ResolvedPlace)->dict:
        pf=preflight()
        # Gate cannot be enabled by forged resolutions/environment flags.
        if not pf.ready:
            numerical_failure=any('RESOURCE_' in r or 'SWISS_RUNTIME_' in r or 'EPHEMERIS_DATE_' in r for r in pf.reasons)
            return {'status':'UNRESOLVED','reason':'EPHEMERIS_STRICT_FAILURE' if numerical_failure else 'M3_RIGHTS_ADMISSION_UNRESOLVED','blockers':list(pf.reasons),'chart':None,'provenance':None}
        if resolved_time.status!='RESOLVED' or place.status!='RESOLVED' or not resolved_time.record or not place.record:
            return {'status':'UNRESOLVED','reason':'INPUT / CHART UNRESOLVED','chart':None,'provenance':None}
        local=resolved_time.record['local_civil']
        original={'place_query_or_selected_ref':place.resolved_place_id,'local_date':local[:10],'local_time':local[11:],'time_precision':'exact','civil_fold':resolved_time.record['requested_fold']}
        replay=place_time_numerical_replay(original)
        if replay['place']!=asdict(place) or replay['civil_time']!=asdict(resolved_time):
            raise ValueError('PLACE_TIME_PROVENANCE_MISMATCH')
        return {'status':'SUCCESS','reason':None,'chart':replay['chart'],'provenance':{**replay,'diagnostic_only':False,'product_activation':True}}

def evaluate(input:dict|None)->dict:
    lock=authority_lock()
    place=FrozenPlaceResolver().resolve((input or {}).get('place_query_or_selected_ref',''))
    civil=FrozenCivilTimeResolver().resolve(input or {},place)
    pf=preflight()
    return {'schema_version':'m3-provenance-2','calendar_policy':'PROLEPTIC_GREGORIAN','coordinate_rule':'CITY_REPRESENTATIVE_V1','authority_lock_sha256':EXPECTED_LOCK_SHA256,
        'place':asdict(place),'civil_time':asdict(civil),'preflight':asdict(pf),
        'chart_status':'NOT_EXECUTED','output_schema_version':None,
        'methodology_calculation_version':None,'swiss_runtime_identity':__import__('determination.e1_restored',fromlist=['runtime_identity']).runtime_identity(),
        'resource_hashes':dict(pf.resource_hashes),'requested_flags':None,'returned_flags':None,
        'missing_authority_objects':lock['missing_authority_objects']}
