from governance.frozen import STOP,TERMINALS,can_execute

def guard(release:dict,input:dict|None=None)->dict:
    from determination.m3 import evaluate
    diagnostic=evaluate(input)
    assert not can_execute('numerical_chart',release)
    row=TERMINALS[STOP]
    return {'exact_code':STOP,'stage':1,'category':row['presentation_category'],
        'mapped_text':row['user_facing_text'],'continuation_requirement':row['continuation_requirement'],
        'reasons':[{'reason_id':'M3_E4_RIGHTS_ADMISSION_ABSENT','cause':'Phase149P froze P1/P2 and admitted pinned place/civil-time resources. The inherited project-specific E4 rights/admission certificate remains absent; product chart activation is off.',
        'dependency_id':'numerical_chart','scope':'This birth-input revision under this release snapshot',
        'resource_ref':'E4_project_specific_applicable_rights_admission_certificate:ABSENT','recoverability':'Requires separately authorized resources and prospective validation',
        'permitted_next_action':'Retain this result; any future authorized continuation must create a new run.'}],
        'm3_resolution':{'place_status':diagnostic['place']['status'],'place_reason':diagnostic['place']['reason'],'civil_time_status':diagnostic['civil_time']['status'],'civil_time_reason':diagnostic['civil_time']['reason'],'authority_lock_sha256':diagnostic['authority_lock_sha256'],'missing_authority_objects':diagnostic['missing_authority_objects']},
        'additional_blockers':[{'dependency_id':'numerical_chart','resource_ref':'E4:UNRESOLVED','evaluated':False}],
        'canonical_available':False,'not_executed_stages':list(range(2,31))}
