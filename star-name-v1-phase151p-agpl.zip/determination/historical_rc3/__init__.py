"""Authenticated RC3 numerical support only; no semantic pipeline."""
