from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from .serialization import canonical_json


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def prefixed_sha256(value: Any) -> str:
    encoded = canonical_json(value).encode("utf-8")
    return "sha256:" + sha256_bytes(encoded)


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
