from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class PassFailUnresolved(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNRESOLVED = "UNRESOLVED"


class EstablishedState(str, Enum):
    ESTABLISHED = "ESTABLISHED"
    NOT_ESTABLISHED = "NOT_ESTABLISHED"
    UNDETERMINABLE = "UNDETERMINABLE"


class EvidenceStatus(str, Enum):
    ENTAILED = "ENTAILED"
    ENTAILED_BY_NECESSARY_CONSEQUENCE = "ENTAILED_BY_NECESSARY_CONSEQUENCE"
    INSUFFICIENT = "INSUFFICIENT"
    UNDETERMINABLE = "UNDETERMINABLE"


class ZodiacSign(str, Enum):
    ARIES = "ARIES"
    TAURUS = "TAURUS"
    GEMINI = "GEMINI"
    CANCER = "CANCER"
    LEO = "LEO"
    VIRGO = "VIRGO"
    LIBRA = "LIBRA"
    SCORPIO = "SCORPIO"
    SAGITTARIUS = "SAGITTARIUS"
    CAPRICORN = "CAPRICORN"
    AQUARIUS = "AQUARIUS"
    PISCES = "PISCES"


class Element(str, Enum):
    FIRE = "FIRE"
    EARTH = "EARTH"
    AIR = "AIR"
    WATER = "WATER"


class PlanetID(str, Enum):
    SUN = "SUN"
    MOON = "MOON"
    MERCURY = "MERCURY"
    VENUS = "VENUS"
    MARS = "MARS"
    JUPITER = "JUPITER"
    SATURN = "SATURN"
    URANUS = "URANUS"
    NEPTUNE = "NEPTUNE"
    PLUTO = "PLUTO"


class AngleID(str, Enum):
    ASC = "ASC"
    MC = "MC"
    DSC = "DSC"
    IC = "IC"


class AspectType(str, Enum):
    CONJUNCTION = "CONJUNCTION"
    SEXTILE = "SEXTILE"
    SQUARE = "SQUARE"
    TRINE = "TRINE"
    OPPOSITION = "OPPOSITION"


class SemanticOperator(str, Enum):
    MOD = "MOD"
    CTX = "CTX"
    REL = "REL"
    REINF = "REINF"


class StructuralRelevancePath(str, Enum):
    REL_EXPLICIT = "REL_EXPLICIT"
    REL_ANGULAR = "REL_ANGULAR"
    REL_ASPECT = "REL_ASPECT"
    REL_CONVERGENCE = "REL_CONVERGENCE"


class ObligationType(str, Enum):
    O3_CONSTITUTIVE = "O3_CONSTITUTIVE"
    O2_MATERIAL = "O2_MATERIAL"
    O1_CONSIDERATION = "O1_CONSIDERATION"


class SemanticType(str, Enum):
    K = "K"
    M = "M"
    S = "S"


class SignatureDimension(str, Enum):
    TYPE = "TYPE"
    SUBSTANCE = "SUBSTANCE"
    PROPERTIES = "PROPERTIES"
    FUNCTIONS = "FUNCTIONS"
    PROCESSES = "PROCESSES"
    RELATIONS = "RELATIONS"
    DIRECTION = "DIRECTION"
    BOUNDARIES = "BOUNDARIES"
    AGENCY = "AGENCY"
    CONTEXT_LIMITS = "CONTEXT_LIMITS"


class RealizationEvidenceState(str, Enum):
    ESTABLISHED = "ESTABLISHED"
    NEGATED = "NEGATED"
    UNRESOLVED = "UNRESOLVED"
    NOT_APPLICABLE = "NOT_APPLICABLE"


class RequirementEntailment(str, Enum):
    ENTAILED = "ENTAILED"
    CONTRADICTED = "CONTRADICTED"
    UNRESOLVED = "UNRESOLVED"


class ConceptMatchOutcome(str, Enum):
    MATCH = "MATCH"
    NO_MATCH = "NO_MATCH"
    PENDING = "PENDING"


class RequirementNodeType(str, Enum):
    ELEMENTAL_FOUNDATION = "ELEMENTAL_FOUNDATION"
    ATOM = "ATOM"
    MOD = "MOD"
    CTX = "CTX"
    REL = "REL"
    REINF = "REINF"


class ElementalFoundationBasis(str, Enum):
    DIRECT_ELEMENT = "DIRECT_ELEMENT"
    ELEMENTAL_FORM = "ELEMENTAL_FORM"
    ELEMENTAL_PROCESS_PHENOMENON = "ELEMENTAL_PROCESS_PHENOMENON"
    DEFINING_ELEMENTAL_RELATION = "DEFINING_ELEMENTAL_RELATION"


class RealizationClass(str, Enum):
    OPERATION = "OPERATION"
    RELATIONAL_OPERATION = "RELATIONAL_OPERATION"
    STATE_PROPERTY = "STATE_PROPERTY"
    MATERIAL_PROPERTY = "MATERIAL_PROPERTY"
    BOUNDARY_OPERATION = "BOUNDARY_OPERATION"
    DIRECTIONAL_OPERATION = "DIRECTIONAL_OPERATION"
    AGENCY_OPERATION = "AGENCY_OPERATION"
    COMPOUND_OPERATION = "COMPOUND_OPERATION"
    RELATIONAL_ARCHITECTURE = "RELATIONAL_ARCHITECTURE"




class BridgeStepType(str, Enum):
    DOCUMENTED_DENOTATION = "DOCUMENTED_DENOTATION"
    INHERENT_PROPERTY = "INHERENT_PROPERTY"
    INHERENT_FUNCTION = "INHERENT_FUNCTION"
    METAPHOR = "METAPHOR"
    ANALOGY = "ANALOGY"
    PERSONAL_ASSOCIATION = "PERSONAL_ASSOCIATION"
    AESTHETIC_ASSOCIATION = "AESTHETIC_ASSOCIATION"
    BIOGRAPHICAL_FIT = "BIOGRAPHICAL_FIT"
    SURNAME_FIT = "SURNAME_FIT"
    UNRESTRICTED_ASSOCIATION = "UNRESTRICTED_ASSOCIATION"


class FreedomCompatibilityState(str, Enum):
    COMPATIBLE = "COMPATIBLE"
    INCOMPATIBLE = "INCOMPATIBLE"
    UNRESOLVED = "UNRESOLVED"


class MethodologyTerminalState(str, Enum):
    CANONICAL_STAR_NAME_ESTABLISHED = "CANONICAL_STAR_NAME_ESTABLISHED"
    NO_QUALIFIED_STAR_NAME = "NO_QUALIFIED_STAR_NAME"
    NO_UNIQUE_STAR_NAME_ESTABLISHED = "NO_UNIQUE_STAR_NAME_ESTABLISHED"
    SEARCH_NOT_CLOSED = "SEARCH_NOT_CLOSED"
    SNEF_PENDING = "SNEF_PENDING"
    NUF_PENDING = "NUF_PENDING"
    F11_UNRESOLVED = "F11_UNRESOLVED"
    TARGET_GENERATION_STOP = "TARGET_GENERATION_STOP"
    CONTRIBUTION_GAP = "CONTRIBUTION_GAP"
    INTEGRATION_STOP = "INTEGRATION_STOP"
    NO_REFERENT_CONCEPT_IN_CURRENT_REGISTRY = "NO_REFERENT_CONCEPT_IN_CURRENT_REGISTRY"
    INPUT_CHART_UNRESOLVED = "INPUT_CHART_UNRESOLVED"
    RESOURCE_COVERAGE_GAP = "RESOURCE_COVERAGE_GAP"
    CROSS_LANGUAGE_ALIGNMENT_UNRESOLVED = "CROSS_LANGUAGE_ALIGNMENT_UNRESOLVED"


class ExecutionFailureState(str, Enum):
    VERSION_LOCK_FAILURE = "VERSION_LOCK_FAILURE"
    CALCULATION_ENVIRONMENT_ERROR = "CALCULATION_ENVIRONMENT_ERROR"
    EPHEMERIS_STRICT_FAILURE = "EPHEMERIS_STRICT_FAILURE"
    LOCAL_TIME_NONEXISTENT = "LOCAL_TIME_NONEXISTENT"
    TIME_FOLD_UNRESOLVED = "TIME_FOLD_UNRESOLVED"
    DATE_OUTSIDE_CALCULATION_RANGE = "DATE_OUTSIDE_CALCULATION_RANGE"
    RESOURCE_INTEGRITY_FAILURE = "RESOURCE_INTEGRITY_FAILURE"
    TARGET_SIGNATURE_PROJECTION_GAP = "TARGET_SIGNATURE_PROJECTION_GAP"
    IMPLEMENTATION_REPRODUCIBILITY_FAILURE = "IMPLEMENTATION_REPRODUCIBILITY_FAILURE"


@dataclass(frozen=True, slots=True)
class ExecutionVersion:
    execution_version_id: str
    ccs_version: str
    chart_semantics_version: str
    semantic_atom_version: str
    projection_version: str
    compatibility_version: str
    concept_registry_version: str
    surname_corpus_version: str
    snef_version: str
    nuf_version: str
    canonicalization_version: str
    serialization_version: str
    identity_schema_version: str
    artifact_manifest_hash: str


@dataclass(frozen=True, slots=True)
class ArtifactRequirement:
    artifact_id: str
    artifact_type: str
    version: str
    relative_path: str
    sha256: str
    required: bool = True


@dataclass(frozen=True, slots=True)
class ArtifactManifest:
    manifest_id: str
    requirements: tuple[ArtifactRequirement, ...]
    manifest_sha256: str


@dataclass(frozen=True, slots=True)
class FundamentalSemanticRoot:
    fundamental_element: Element
    sun_mode_atom_id: str


@dataclass(frozen=True, slots=True)
class SemanticExpression:
    operator: SemanticOperator | None
    atom_id: str | None
    operands: tuple["SemanticExpression", ...] = ()
    provenance_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        is_leaf = self.operator is None
        if is_leaf != (self.atom_id is not None):
            raise ValueError("SemanticExpression must be either a leaf atom or an operator node")
        if is_leaf and self.operands:
            raise ValueError("Leaf semantic expressions cannot have operands")
        if not is_leaf and not self.operands:
            raise ValueError("Operator semantic expressions require operands")


@dataclass(frozen=True, slots=True)
class TargetIdentityPayload:
    fundamental_element: str
    sun_mode_atom_id: str
    mandatory_expression_payloads: tuple[Any, ...]
    mandatory_relation_payloads: tuple[Any, ...]


@dataclass(frozen=True, slots=True)
class ProjectionRequirementNode:
    node_type: RequirementNodeType
    element: Element | None = None
    atom_id: str | None = None
    children: tuple["ProjectionRequirementNode", ...] = ()
    relation_atom_id: str | None = None
    context_atom_id: str | None = None
    source_expression_fingerprint: str | None = None


@dataclass(frozen=True, slots=True)
class ProjectedTargetRequirements:
    target_id: str
    elemental_foundation: ProjectionRequirementNode
    operating_mode: ProjectionRequirementNode
    mandatory_patterns: tuple[ProjectionRequirementNode, ...]
    mandatory_relations: tuple[ProjectionRequirementNode, ...]
    projection_version: str
    projection_fingerprint: str


@dataclass(frozen=True, slots=True)
class SemanticAtom:
    atom_id: str
    canonical_gloss: str
    source_family: str
    realization_class: RealizationClass
    allowed_dimensions: tuple[SignatureDimension, ...]
    atomic_cluster: bool
    source_rule_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ElementalRealization:
    concept_id: str
    element: Element
    basis: ElementalFoundationBasis
    state: RealizationEvidenceState
    evidence_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class SemanticRealizationAssertion:
    assertion_id: str
    concept_id: str
    atom_id: str
    dimension: SignatureDimension
    state: RealizationEvidenceState
    evidence_ids: tuple[str, ...]
    context_limit: str | None = None


@dataclass(frozen=True, slots=True)
class IntegratedRealization:
    concept_id: str
    expression_fingerprint: str
    component_assertion_ids: tuple[str, ...]
    state: RealizationEvidenceState
    evidence_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class RelationalRealization:
    concept_id: str
    left_expression_fingerprint: str
    relation_atom_id: str
    right_expression_fingerprint: str
    state: RealizationEvidenceState
    evidence_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class NegativeRealizationEvidence:
    concept_id: str
    atom_id: str
    dimension: SignatureDimension
    scope: str | None
    reason_code: str
    evidence_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ConceptRealizationEvidence:
    concept_id: str
    elemental_realizations: tuple[ElementalRealization, ...] = ()
    atom_realizations: tuple[SemanticRealizationAssertion, ...] = ()
    integrated_realizations: tuple[IntegratedRealization, ...] = ()
    relational_realizations: tuple[RelationalRealization, ...] = ()
    negative_realizations: tuple[NegativeRealizationEvidence, ...] = ()


@dataclass(frozen=True, slots=True)
class StarIdentityPayload:
    canonical_branch_fingerprint: str
    canonical_concept_fingerprint: str
    target_fingerprint: str
    identity_schema_version: str

@dataclass(frozen=True, slots=True)
class RequirementMatchAudit:
    requirement_fingerprint: str
    node_type: RequirementNodeType
    state: RequirementEntailment
    positive_evidence_ids: tuple[str, ...] = ()
    negative_evidence_ids: tuple[str, ...] = ()
    reason_code: str = ""


@dataclass(frozen=True, slots=True)
class ConceptMatchAudit:
    concept_id: str
    target_id: str
    projection_fingerprint: str
    requirement_audits: tuple[RequirementMatchAudit, ...]
    outcome: ConceptMatchOutcome
    match_fingerprint: str

class ParentRelationType(str, Enum):
    IS_A = "IS_A"
    SUBTYPE_OF = "SUBTYPE_OF"
    INSTANCE_CLASS_PARENT = "INSTANCE_CLASS_PARENT"


@dataclass(frozen=True, slots=True)
class ParentRelation:
    child_concept_id: str
    parent_concept_id: str
    relation_type: ParentRelationType
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ConceptStructuralRecord:
    concept_id: str
    structural_specificity_state: PassFailUnresolved
    structural_specificity_evidence_ids: tuple[str, ...] = ()
    included: bool = True
    distinct: bool = True


@dataclass(frozen=True, slots=True)
class HierarchyIndex:
    parent_relations: tuple[ParentRelation, ...]
    parents_by_child: tuple[tuple[str, tuple[str, ...]], ...]
    children_by_parent: tuple[tuple[str, tuple[str, ...]], ...]
    neighbors_by_concept: tuple[tuple[str, tuple[str, ...]], ...]
    hierarchy_fingerprint: str


@dataclass(frozen=True, slots=True)
class CoverageAudit:
    concept_id: str
    outcome: ConceptMatchOutcome
    match_fingerprint: str




@dataclass(frozen=True, slots=True)
class DerivationStepEvidence:
    step_id: str
    source_form: str
    target_form_or_meaning: str
    state: EstablishedState
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class AttestedMeaningEvidence:
    branch_id: str
    exact_form: str
    terminal_denotation: str
    derivation_steps: tuple[DerivationStepEvidence, ...]
    endpoint_state: EstablishedState
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class OperativeReferentEvidence:
    referent_id: str
    state: EstablishedState
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SingleReferentEvidence:
    branch_id: str
    referents: tuple[OperativeReferentEvidence, ...]


@dataclass(frozen=True, slots=True)
class FreedomCompatibilityEvidence:
    branch_id: str
    state: FreedomCompatibilityState
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class InterpretiveBridgeStepEvidence:
    step_id: str
    step_type: BridgeStepType
    status: EvidenceStatus
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class InterpretiveBridgeEvidence:
    branch_id: str
    steps: tuple[InterpretiveBridgeStepEvidence, ...]


@dataclass(frozen=True, slots=True)
class SNEFCandidateEvidenceBundle:
    branch_id: str
    attested_meaning: AttestedMeaningEvidence
    single_referent: SingleReferentEvidence
    freedom_compatibility: FreedomCompatibilityEvidence
    interpretive_bridge: InterpretiveBridgeEvidence


@dataclass(frozen=True, slots=True)
class SNEFGateResult:
    gate_id: str
    state: PassFailUnresolved
    reason_code: str
    evidence_ids: tuple[str, ...] = ()
    related_concept_ids: tuple[str, ...] = ()


class SNEFOutcome(str, Enum):
    ELIGIBLE = "ELIGIBLE"
    INELIGIBLE = "INELIGIBLE"
    PENDING = "PENDING"


@dataclass(frozen=True, slots=True)
class SNEFResult:
    concept_id: str
    target_id: str
    gate_results: tuple[SNEFGateResult, ...]
    outcome: SNEFOutcome
    snef_fingerprint: str
    candidate_branch_id: str | None = None


class NUFClass(str, Enum):
    P = "P"
    N = "N"
    X = "X"
    U = "U"


class NUFBranchGateID(str, Enum):
    S1 = "S1"  # surname attestation
    S2 = "S2"  # authentic form
    S3 = "S3"  # personal-name function
    S4 = "S4"  # documented branch identity
    S5 = "S5"  # meaning attribution


class I2ScreenFactor(str, Enum):
    # The substantive definitions of F1-F7 remain external frozen evidence-policy inputs.
    # BUILD-8 aggregates them without inventing meanings for the factor labels.
    F1 = "F1"
    F2 = "F2"
    F3 = "F3"
    F4 = "F4"
    F5 = "F5"
    F6 = "F6"
    F7 = "F7"


class NUFOutcome(str, Enum):
    ELIGIBLE = "ELIGIBLE"
    INELIGIBLE = "INELIGIBLE"
    PENDING = "PENDING"


class F11Outcome(str, Enum):
    RESOLVED_SINGLE_I1 = "RESOLVED_SINGLE_I1"
    UNRESOLVED_MULTIPLE_I1 = "UNRESOLVED_MULTIPLE_I1"


@dataclass(frozen=True, slots=True)
class NUFBranchGateEvidence:
    gate_id: NUFBranchGateID
    state: EstablishedState
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class BranchNUFEvidence:
    branch_id: str
    gates: tuple[NUFBranchGateEvidence, ...]
    semantic_class: NUFClass
    semantic_class_evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class I2ScreenEvidence:
    factor_id: I2ScreenFactor
    state: PassFailUnresolved
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ExactFormNUFEvidence:
    exact_form_id: str
    exact_form: str
    branch_id: str
    screen_factors: tuple[I2ScreenEvidence, ...]
    x_trigger_state: EstablishedState = EstablishedState.NOT_ESTABLISHED
    x_trigger_evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class NUFCheckResult:
    check_id: str
    state: PassFailUnresolved
    reason_code: str
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class NUFResult:
    branch_id: str
    exact_form_id: str
    semantic_class: NUFClass
    check_results: tuple[NUFCheckResult, ...]
    outcome: NUFOutcome
    nuf_fingerprint: str


@dataclass(frozen=True, slots=True)
class F11Result:
    exact_form_id: str
    branch_ids: tuple[str, ...]
    outcome: F11Outcome
    reason_code: str
    f11_fingerprint: str

class MappingRelation(str, Enum):
    EXACT = "EXACT"
    BROADER = "BROADER"
    NARROWER = "NARROWER"
    OVERLAPPING = "OVERLAPPING"
    RELATED = "RELATED"
    NONE = "NONE"
    UNRESOLVED = "UNRESOLVED"


class BranchVerificationStatus(str, Enum):
    VERIFIED = "VERIFIED"
    REJECTED = "REJECTED"
    UNRESOLVED = "UNRESOLVED"


class FrontierClosureState(str, Enum):
    CLOSED = "CLOSED"
    OPEN = "OPEN"


@dataclass(frozen=True, slots=True)
class AuthorizedNarrowerEdge:
    parent_concept_id: str
    child_concept_id: str
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SurnameSearchBranchRecord:
    branch_id: str
    verification_status: BranchVerificationStatus
    frontier_id: str


@dataclass(frozen=True, slots=True)
class SurnameConceptMappingRecord:
    branch_id: str
    concept_id: str
    relation: MappingRelation
    state: EstablishedState
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class PendingBranchConceptPossibility:
    branch_id: str
    possible_concept_ids: tuple[str, ...]
    evidence_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SurnameFrontierRecord:
    frontier_id: str
    authorized_for_canonical: bool
    traversal_complete: bool
    all_entries_disposed: bool
    mappings_complete: bool
    reproducible: bool
    branch_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SearchFamily:
    seed_concept_id: str
    family_concept_ids: tuple[str, ...]
    direct_branch_ids: tuple[str, ...]
    authorized_narrower_concept_ids: tuple[str, ...]
    expanded_branch_ids: tuple[str, ...]
    pending_branch_ids: tuple[str, ...]
    required_frontier_ids: tuple[str, ...]
    family_closed: bool
    family_hash: str


@dataclass(frozen=True, slots=True)
class SearchAdequacyResult:
    target_id: str
    search_families: tuple[SearchFamily, ...]
    search_closed: bool
    material_pending_branch_ids: tuple[str, ...]
    material_pending_concept_ids: tuple[str, ...]
    adequate: bool
    reason_code: str
    search_fingerprint: str


@dataclass(frozen=True, slots=True)
class BranchResolutionInput:
    branch_id: str
    concept_id: str
    snef_result: SNEFResult
    nuf_results: tuple[NUFResult, ...]
    f11_results: tuple[F11Result, ...]


@dataclass(frozen=True, slots=True)
class QualifiedCandidate:
    branch_id: str
    concept_id: str
    eligible_exact_form_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class QualifiedPool:
    target_id: str
    qualified_candidates: tuple[QualifiedCandidate, ...]
    snef_pending_branch_ids: tuple[str, ...]
    nuf_pending_branch_ids: tuple[str, ...]
    f11_unresolved_branch_ids: tuple[str, ...]
    pool_fingerprint: str


@dataclass(frozen=True, slots=True)
class QCAResult:
    candidate_branch_ids: tuple[str, ...]
    authorized_dimensions: tuple[str, ...]
    dominance_edges: tuple[tuple[str, str], ...]
    non_dominated_branch_ids: tuple[str, ...]
    qca_fingerprint: str


@dataclass(frozen=True, slots=True)
class CanonicalizationResult:
    target_id: str
    terminal_state: MethodologyTerminalState
    canonical_branch_id: str | None
    canonical_concept_id: str | None
    qualified_pool_fingerprint: str | None
    qca_fingerprint: str | None
    search_fingerprint: str
    canonicalization_fingerprint: str

@dataclass(frozen=True, slots=True)
class StarIDRecord:
    star_id: str
    identity_hash: str
    identity_payload: StarIdentityPayload


@dataclass(frozen=True, slots=True)
class AuditEvent:
    sequence: int
    stage: str
    operation: str
    input_hash: str
    output_hash: str
    rule_ids: tuple[str, ...] = ()
    evidence_ids: tuple[str, ...] = ()
    status: str = "OK"


@dataclass(frozen=True, slots=True)
class DeterministicOutcomePayload:
    execution_version_id: str
    birth_semantic_input_hash: str
    chart_fingerprint: str | None
    target_fingerprint: str | None
    projection_fingerprint: str | None
    search_fingerprint: str | None
    canonicalization_fingerprint: str | None
    methodology_terminal_state: MethodologyTerminalState | None
    execution_failure_state: ExecutionFailureState | None
    canonical_branch_fingerprint: str | None
    canonical_concept_fingerprint: str | None
    star_id: str | None


@dataclass(frozen=True, slots=True)
class StarNameRun:
    run_id: str
    execution_version_id: str
    birth_semantic_input_hash: str
    chart_fingerprint: str | None = None
    target_id: str | None = None
    target_fingerprint: str | None = None
    projection_fingerprint: str | None = None
    search_fingerprint: str | None = None
    canonicalization_fingerprint: str | None = None
    canonical_branch_id: str | None = None
    canonical_concept_id: str | None = None
    star_id: str | None = None
    methodology_terminal_state: MethodologyTerminalState | None = None
    execution_failure_state: ExecutionFailureState | None = None
    deterministic_outcome_hash: str | None = None
    audit_log_hash: str | None = None
    execution_record_hash: str | None = None

    def __post_init__(self) -> None:
        if (
            self.methodology_terminal_state is not None
            and self.execution_failure_state is not None
        ):
            raise ValueError(
                "A terminated run cannot simultaneously hold a methodology terminal "
                "state and an execution failure state"
            )
