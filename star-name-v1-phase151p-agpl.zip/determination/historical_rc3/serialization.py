from __future__ import annotations

import json
from datetime import date, datetime, timezone
from dataclasses import fields, is_dataclass
from enum import Enum
from typing import Any


class CanonicalSerializationError(TypeError):
    pass


def to_canonical_data(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, bool)):
        return value


    if isinstance(value, datetime):
        if value.tzinfo is None:
            raise CanonicalSerializationError("Naive datetimes are forbidden in canonical serialization")
        utc = value.astimezone(timezone.utc)
        return utc.isoformat(timespec="microseconds").replace("+00:00", "Z")

    if isinstance(value, date):
        return value.isoformat()

    if isinstance(value, float):
        raise CanonicalSerializationError(
            "Floats are forbidden in identity-bearing canonical serialization"
        )

    if isinstance(value, Enum):
        return value.value

    if is_dataclass(value):
        return {
            f.name: to_canonical_data(getattr(value, f.name))
            for f in fields(value)
        }

    if isinstance(value, tuple):
        return [to_canonical_data(v) for v in value]

    if isinstance(value, list):
        return [to_canonical_data(v) for v in value]

    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, val in value.items():
            if not isinstance(key, str):
                raise CanonicalSerializationError("Canonical dict keys must be strings")
            out[key] = to_canonical_data(val)
        return out

    raise CanonicalSerializationError(
        f"Unsupported canonical serialization type: {type(value).__name__}"
    )


def canonical_json(value: Any) -> str:
    return json.dumps(
        to_canonical_data(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )
