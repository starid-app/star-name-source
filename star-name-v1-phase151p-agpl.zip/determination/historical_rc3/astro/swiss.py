from __future__ import annotations

from datetime import timezone
from decimal import Decimal, ROUND_HALF_EVEN
from pathlib import Path

import swisseph as swe
import hashlib

from .models import (
    DEGREE_SCALE, AnglePosition, AngularProminenceRecord, AspectRecord,
    CalculationManifest, ChartRecord, PlanetPosition, ValidatedBirthInput,
)
from ..core_types import AngleID, AspectType, ExecutionFailureState, PlanetID, ZodiacSign
from ..hashing import prefixed_sha256


class CalculationEnvironmentError(RuntimeError):
    def __init__(self, state: ExecutionFailureState, message: str):
        super().__init__(message)
        self.state = state



LOCKED_EPHEMERIS_SHA256 = {
    "sepl_18.se1": "ca1393ceab3a44fbc895887cf789c68819ae6a1cbc9b22225872dbe4ccd99a66",
    "semo_18.se1": "1ca07bd67c24374d77226180c20a4f9996cba013697894810518e7eb582ca4f7",
}

def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _strict_ephemeris_preflight(ephemeris_path: str | None) -> None:
    if not ephemeris_path:
        raise CalculationEnvironmentError(
            ExecutionFailureState.EPHEMERIS_STRICT_FAILURE,
            "Strict Swiss Ephemeris mode requires the locked ephemeris path",
        )
    root = Path(ephemeris_path)
    if not root.is_dir():
        raise CalculationEnvironmentError(ExecutionFailureState.EPHEMERIS_STRICT_FAILURE, f"Ephemeris directory unavailable: {root}")
    for filename, expected in LOCKED_EPHEMERIS_SHA256.items():
        artifact = root / filename
        if not artifact.is_file():
            raise CalculationEnvironmentError(ExecutionFailureState.EPHEMERIS_STRICT_FAILURE, f"Missing locked ephemeris artifact: {filename}")
        actual = _sha256_file(artifact)
        if actual != expected:
            raise CalculationEnvironmentError(ExecutionFailureState.EPHEMERIS_STRICT_FAILURE, f"Ephemeris hash mismatch: {filename}")

PLANET_CODES = {
    PlanetID.SUN: swe.SUN, PlanetID.MOON: swe.MOON, PlanetID.MERCURY: swe.MERCURY,
    PlanetID.VENUS: swe.VENUS, PlanetID.MARS: swe.MARS, PlanetID.JUPITER: swe.JUPITER,
    PlanetID.SATURN: swe.SATURN, PlanetID.URANUS: swe.URANUS, PlanetID.NEPTUNE: swe.NEPTUNE,
    PlanetID.PLUTO: swe.PLUTO,
}
SIGNS = tuple(ZodiacSign)
RULERS = {
    ZodiacSign.ARIES: PlanetID.MARS, ZodiacSign.TAURUS: PlanetID.VENUS,
    ZodiacSign.GEMINI: PlanetID.MERCURY, ZodiacSign.CANCER: PlanetID.MOON,
    ZodiacSign.LEO: PlanetID.SUN, ZodiacSign.VIRGO: PlanetID.MERCURY,
    ZodiacSign.LIBRA: PlanetID.VENUS, ZodiacSign.SCORPIO: PlanetID.MARS,
    ZodiacSign.SAGITTARIUS: PlanetID.JUPITER, ZodiacSign.CAPRICORN: PlanetID.SATURN,
    ZodiacSign.AQUARIUS: PlanetID.SATURN, ZodiacSign.PISCES: PlanetID.JUPITER,
}
ASPECT_SPECS = (
    (AspectType.CONJUNCTION, 0, 8), (AspectType.SEXTILE, 60, 4),
    (AspectType.SQUARE, 90, 8), (AspectType.TRINE, 120, 12),
    (AspectType.OPPOSITION, 180, 8),
)


def quantize_degree_e7(value: float) -> int:
    norm = Decimal(str(value % 360.0)) * DEGREE_SCALE
    out = int(norm.quantize(Decimal("1"), rounding=ROUND_HALF_EVEN))
    return out % (360 * DEGREE_SCALE)


def sign_from_longitude_e7(longitude_e7: int) -> ZodiacSign:
    return SIGNS[(longitude_e7 // (30 * DEGREE_SCALE)) % 12]


def circular_distance_e7(a: int, b: int) -> int:
    full = 360 * DEGREE_SCALE
    d = abs(a - b) % full
    return min(d, full - d)


def _julian_day(utc_dt) -> float:
    u = utc_dt.astimezone(timezone.utc)
    hour = u.hour + u.minute / 60 + (u.second + u.microsecond / 1_000_000) / 3600
    return swe.julday(u.year, u.month, u.day, hour, swe.GREG_CAL)


def _whole_sign_house(longitude_e7: int, asc_e7: int) -> int:
    sign_idx = longitude_e7 // (30 * DEGREE_SCALE)
    asc_idx = asc_e7 // (30 * DEGREE_SCALE)
    return ((sign_idx - asc_idx) % 12) + 1


def _aspect_for_distance(distance_e7: int):
    deg = Decimal(distance_e7) / DEGREE_SCALE
    for aspect, exact, orb in ASPECT_SPECS:
        delta = abs(deg - Decimal(exact))
        if delta <= Decimal(orb):
            return aspect, quantize_degree_e7(float(delta))
    return None


def _calc_aspects(planets: tuple[PlanetPosition, ...], angles: tuple[AnglePosition, ...]):
    endpoints = [(p.planet.value, p.longitude_e7) for p in planets]
    result = []
    # P x P unordered
    for i in range(len(endpoints)):
        for j in range(i + 1, len(endpoints)):
            left, right = endpoints[i], endpoints[j]
            d = circular_distance_e7(left[1], right[1])
            match = _aspect_for_distance(d)
            if match:
                result.append(AspectRecord(left[0], right[0], match[0], d, match[1]))
    # P x all four angles; no angle-angle aspects.
    for pid, plong in endpoints:
        for angle in angles:
            d = circular_distance_e7(plong, angle.longitude_e7)
            match = _aspect_for_distance(d)
            if match:
                result.append(AspectRecord(pid, angle.angle.value, match[0], d, match[1]))
    return tuple(sorted(result, key=lambda x: (x.left_id, x.right_id, x.aspect.value)))


def _manifest(ephemeris_path: str | None, strict: bool, mode: str):
    return CalculationManifest(
        backend_name="Swiss Ephemeris",
        backend_version=str(swe.version),
        ephemeris_mode=mode,
        ephemeris_path=ephemeris_path,
        strict_swiss_ephemeris=strict,
        timezone_source="IANA/tzdata",
    )


def calculate_chart(validated: ValidatedBirthInput, *, ephemeris_path: str | None = None,
                    strict_swiss_ephemeris: bool = True) -> ChartRecord:
    if strict_swiss_ephemeris:
        _strict_ephemeris_preflight(ephemeris_path)
    if ephemeris_path:
        if not Path(ephemeris_path).exists():
            raise CalculationEnvironmentError(
                ExecutionFailureState.RESOURCE_INTEGRITY_FAILURE,
                f"Ephemeris path does not exist: {ephemeris_path}",
            )
        swe.set_ephe_path(ephemeris_path)
    jd = _julian_day(validated.utc_datetime)
    flags_req = swe.FLG_SWIEPH | swe.FLG_SPEED
    raw = {}
    used_modes = set()
    for planet, code in PLANET_CODES.items():
        try:
            values, returned_flags = swe.calc_ut(jd, code, flags_req)
        except Exception as exc:
            raise CalculationEnvironmentError(
                ExecutionFailureState.CALCULATION_ENVIRONMENT_ERROR,
                f"Swiss Ephemeris calculation failed for {planet.value}: {exc}",
            ) from exc
        mode = "SWIEPH" if returned_flags & swe.FLG_SWIEPH else "MOSEPH" if returned_flags & swe.FLG_MOSEPH else "OTHER"
        used_modes.add(mode)
        if strict_swiss_ephemeris and mode != "SWIEPH":
            raise CalculationEnvironmentError(
                ExecutionFailureState.EPHEMERIS_STRICT_FAILURE,
                "Strict Swiss Ephemeris mode requested but backend fell back to Moshier/other ephemeris",
            )
        raw[planet] = quantize_degree_e7(values[0])
    if len(used_modes) != 1:
        raise CalculationEnvironmentError(
            ExecutionFailureState.CALCULATION_ENVIRONMENT_ERROR,
            f"Mixed ephemeris modes are not authorized: {sorted(used_modes)}",
        )
    lat = validated.latitude_e7 / DEGREE_SCALE
    lon = validated.longitude_e7 / DEGREE_SCALE
    try:
        cusps, ascmc = swe.houses_ex(jd, lat, lon, b'P', swe.FLG_TROPICAL)
    except Exception as exc:
        raise CalculationEnvironmentError(
            ExecutionFailureState.CALCULATION_ENVIRONMENT_ERROR,
            f"Angle calculation failed: {exc}",
        ) from exc
    asc = quantize_degree_e7(ascmc[0]); mc = quantize_degree_e7(ascmc[1])
    full = 360 * DEGREE_SCALE; half = 180 * DEGREE_SCALE
    angles = (
        AnglePosition(AngleID.ASC, asc, sign_from_longitude_e7(asc)),
        AnglePosition(AngleID.MC, mc, sign_from_longitude_e7(mc)),
        AnglePosition(AngleID.DSC, (asc + half) % full, sign_from_longitude_e7((asc + half) % full)),
        AnglePosition(AngleID.IC, (mc + half) % full, sign_from_longitude_e7((mc + half) % full)),
    )
    planets = tuple(
        PlanetPosition(p, raw[p], sign_from_longitude_e7(raw[p]), _whole_sign_house(raw[p], asc))
        for p in PlanetID
    )
    aspects = _calc_aspects(planets, angles)
    five = 5 * DEGREE_SCALE
    angular_houses = {1, 4, 7, 10}
    prominence = tuple(
        AngularProminenceRecord(
            p.planet,
            p.house_number in angular_houses,
            any(circular_distance_e7(p.longitude_e7, a.longitude_e7) <= five for a in angles),
        ) for p in planets
    )
    manifest = _manifest(ephemeris_path, strict_swiss_ephemeris, next(iter(used_modes)))
    identity = {
        "utc": validated.utc_datetime,
        "lat_e7": validated.latitude_e7,
        "lon_e7": validated.longitude_e7,
        "planets": planets,
        "angles": angles,
        "aspects": aspects,
        "prominence": prominence,
        "ascendant_ruler": RULERS[angles[0].sign],
        "calculation": {
            "backend_name": manifest.backend_name,
            "backend_version": manifest.backend_version,
            "ephemeris_mode": manifest.ephemeris_mode,
            "house_system": manifest.house_system,
            "zodiac": manifest.zodiac,
            "frame": manifest.frame,
        },
    }
    fingerprint = prefixed_sha256(identity)
    return ChartRecord(
        validated_birth=validated,
        manifest=manifest,
        planets=planets,
        angles=angles,
        aspects=aspects,
        angular_prominence=prominence,
        ascendant_ruler=RULERS[angles[0].sign],
        chart_fingerprint=fingerprint,
    )
