from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from ..core_types import AngleID, AspectType, PlanetID, ZodiacSign

DEGREE_SCALE = 10_000_000


@dataclass(frozen=True, slots=True)
class BirthInput:
    local_datetime: datetime
    timezone_id: str
    latitude_e7: int
    longitude_e7: int
    known_utc_offset_minutes: int | None = None


@dataclass(frozen=True, slots=True)
class ValidatedBirthInput:
    local_datetime: datetime
    timezone_id: str
    utc_datetime: datetime
    utc_offset_minutes: int
    fold: int
    latitude_e7: int
    longitude_e7: int


@dataclass(frozen=True, slots=True)
class PlanetPosition:
    planet: PlanetID
    longitude_e7: int
    sign: ZodiacSign
    house_number: int


@dataclass(frozen=True, slots=True)
class AnglePosition:
    angle: AngleID
    longitude_e7: int
    sign: ZodiacSign


@dataclass(frozen=True, slots=True)
class AspectRecord:
    left_id: str
    right_id: str
    aspect: AspectType
    separation_e7: int
    orb_distance_e7: int


@dataclass(frozen=True, slots=True)
class AngularProminenceRecord:
    planet: PlanetID
    by_angular_house: bool
    by_angle_proximity: bool


@dataclass(frozen=True, slots=True)
class CalculationManifest:
    backend_name: str
    backend_version: str
    ephemeris_mode: str
    ephemeris_path: str | None
    strict_swiss_ephemeris: bool
    timezone_source: str
    house_system: str = "WHOLE_SIGN"
    zodiac: str = "TROPICAL"
    frame: str = "GEOCENTRIC_APPARENT"


@dataclass(frozen=True, slots=True)
class ChartRecord:
    validated_birth: ValidatedBirthInput
    manifest: CalculationManifest
    planets: tuple[PlanetPosition, ...]
    angles: tuple[AnglePosition, ...]
    aspects: tuple[AspectRecord, ...]
    angular_prominence: tuple[AngularProminenceRecord, ...]
    ascendant_ruler: PlanetID
    chart_fingerprint: str
