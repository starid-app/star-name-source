"""RC3 numerical modules; timezone resolver intentionally excluded."""
