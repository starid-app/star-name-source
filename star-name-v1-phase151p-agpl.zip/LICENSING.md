# Star Name v1 licensing
The owner selected A_AGPL_OPEN_SOURCE_COMPATIBLE_V1 on 2026-10-01. Star Name original application source in this release is licensed under GNU Affero General Public License version 3 or later (SPDX: AGPL-3.0-or-later). Copyright 2026 Star Name project contributors. Full terms in LICENSE; no warranty.

Third-party files retain their original copyrights and grants. PySwissEph uses AGPL-3.0-or-later; Swiss Ephemeris uses the selected AGPL route; Swephelp uses its GPL-3.0-or-later option for the combined AGPL work. Its GPL-2.0-or-later headers remain unchanged. GeoNames data remains CC BY 4.0, independent of the application license. IANA and SQLite retain their supplied grants. See compliance/THIRD_PARTY_NOTICES.md and original sources. Service fees are permitted; corresponding-source downloads are free.

Source availability excludes users' private birth inputs, accounts, databases, backups, credentials, keys, StarIDs and private share tokens. Configure secrets locally; never add them to this archive.
