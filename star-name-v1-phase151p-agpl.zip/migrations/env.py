from alembic import context
from sqlalchemy import create_engine
from api.config import Settings
from persistence.models import Base
settings=Settings.load()
engine=create_engine(settings.database_url,hide_parameters=True,pool_pre_ping=True)
with engine.connect() as connection:
    if engine.dialect.name=='sqlite': connection.exec_driver_sql('PRAGMA foreign_keys=ON'); connection.commit()
    context.configure(connection=connection,target_metadata=Base.metadata)
    with context.begin_transaction(): context.run_migrations()
