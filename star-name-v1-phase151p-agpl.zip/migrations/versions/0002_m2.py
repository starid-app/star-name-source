"""Separate erasable ciphertext from immutable provenance; deduplicate semantic audit events."""
from alembic import op
import sqlalchemy as sa
revision='0002'
down_revision='0001'
branch_labels=None
depends_on=None
def upgrade():
    bind=op.get_bind()
    op.create_table('birth_vault',sa.Column('birth_id',sa.String(),sa.ForeignKey('birth_inputs.id'),primary_key=True),sa.Column('ciphertext',sa.Text(),nullable=False),sa.Column('key_version',sa.String(),nullable=False))
    op.create_table('account_redactions',sa.Column('owner_id',sa.String(),sa.ForeignKey('accounts.id'),primary_key=True),sa.Column('created_at',sa.String(),nullable=False))
    bind.execute(sa.text("INSERT INTO birth_vault(birth_id,ciphertext,key_version) SELECT id,encrypted,'v1' FROM birth_inputs"))
    if bind.dialect.name=='postgresql':
        bind.execute(sa.text('DROP TRIGGER immutable_birth_inputs ON birth_inputs'))
    else:
        bind.execute(sa.text('DROP TRIGGER immutable_birth_inputs_UPDATE'))
    bind.execute(sa.text("UPDATE birth_inputs SET encrypted='VAULT_SEPARATED_M2'"))
    if bind.dialect.name=='postgresql':
        bind.execute(sa.text('CREATE TRIGGER immutable_birth_inputs BEFORE UPDATE OR DELETE ON birth_inputs FOR EACH ROW EXECUTE FUNCTION reject_immutable()'))
        bind.execute(sa.text('CREATE TRIGGER immutable_account_redactions BEFORE UPDATE OR DELETE ON account_redactions FOR EACH ROW EXECUTE FUNCTION reject_immutable()'))
    else:
        bind.execute(sa.text("CREATE TRIGGER immutable_birth_inputs_UPDATE BEFORE UPDATE ON birth_inputs BEGIN SELECT RAISE(ABORT, 'append-only record'); END"))
        for action in ['UPDATE','DELETE']:
            bind.execute(sa.text(f"CREATE TRIGGER immutable_account_redactions_{action} BEFORE {action} ON account_redactions BEGIN SELECT RAISE(ABORT, 'append-only record'); END"))
    with op.batch_alter_table('audit_events') as batch:
        batch.create_unique_constraint('uq_audit_semantic_event',['object_id','action'])
    if bind.dialect.name=='sqlite':
        for action in ['UPDATE','DELETE']:
            bind.execute(sa.text(f"CREATE TRIGGER IF NOT EXISTS immutable_audit_events_{action} BEFORE {action} ON audit_events BEGIN SELECT RAISE(ABORT, 'append-only record'); END"))
def downgrade():
    raise RuntimeError('Destructive rollback disabled; use a forward migration')
