"""Initial owner vault, immutable runs and durable jobs."""
from alembic import op
from sqlalchemy import text
from migrations.schema_v1 import Base
revision='0001'
down_revision=None
branch_labels=None
depends_on=None
def upgrade():
    bind=op.get_bind(); Base.metadata.create_all(bind)
    import json,hashlib
    from governance.frozen import TERMINALS,snapshot
    from persistence.models import TerminalState,Release
    bind.execute(TerminalState.__table__.insert(),[{'id':key,'payload':json.dumps(value,sort_keys=True)} for key,value in TERMINALS.items()])
    payload=json.dumps(snapshot(),sort_keys=True)
    bind.execute(Release.__table__.insert(),{'id':hashlib.sha256(payload.encode()).hexdigest(),'payload':payload})
    immutable=['terminal_states','birth_inputs','releases','runs','outcomes','stages','audit_events','outbox']
    if bind.dialect.name=='postgresql':
        bind.execute(text("CREATE FUNCTION reject_immutable() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'append-only record'; END; $$"))
        for table in immutable:
            bind.execute(text(f'CREATE TRIGGER immutable_{table} BEFORE UPDATE OR DELETE ON {table} FOR EACH ROW EXECUTE FUNCTION reject_immutable()'))
    else:
        for table in immutable:
            for action in ['UPDATE','DELETE']:
                bind.execute(text(f"CREATE TRIGGER immutable_{table}_{action} BEFORE {action} ON {table} BEGIN SELECT RAISE(ABORT, 'append-only record'); END"))
def downgrade():
    raise RuntimeError('Destructive rollback disabled; use a forward migration')
