"""Private erasable M3 provenance; immutable owner/input/release refs remain in runs."""
from alembic import op
import sqlalchemy as sa
revision='0003'
down_revision='0002'
branch_labels=None
depends_on=None
def upgrade():
    op.create_table('chart_provenance_vault',sa.Column('run_id',sa.String(),sa.ForeignKey('runs.id'),primary_key=True),sa.Column('ciphertext',sa.Text(),nullable=False),sa.Column('key_version',sa.String(),nullable=False))
def downgrade():
    raise RuntimeError('Destructive rollback disabled; use a forward migration')
