import os
from dataclasses import dataclass
from cryptography.fernet import Fernet
@dataclass(frozen=True)
class Settings:
    database_url:str
    vault_key:str
    dev_auth:bool
    dev_tokens:dict[str,str]
    key_version:str="v1"
    vault_keys:dict[str,str]|None=None
    def __post_init__(self):
        import re
        if os.getenv('APP_ENV')!='development' or not self.dev_auth or not self.dev_tokens:
            raise RuntimeError('Development configuration required; production unavailable')
        for token,owner in self.dev_tokens.items():
            if len(token)<24 or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',owner):
                raise RuntimeError('Use opaque development owner identifiers')
        Fernet(self.vault_key.encode())
    @classmethod
    def load(cls):
        if os.getenv('APP_ENV','')!='development':
            raise RuntimeError('Production auth adapter is not implemented; startup disabled')
        enabled=os.getenv('DEV_AUTH')=='true'
        tokens={}
        for entry in os.getenv('DEV_TOKENS','').split(','):
            if entry:
                token,owner=entry.split(':',1)
                if len(token)<24 or not owner: raise RuntimeError('Invalid development credentials')
                tokens[token]=owner
        if not enabled or not tokens: raise RuntimeError('Explicit development auth configuration required')
        key=os.environ['VAULT_KEY']; Fernet(key.encode())
        import json,re
        version=os.getenv('VAULT_KEY_VERSION','v1')
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',version): raise RuntimeError('Invalid key version')
        keys=json.loads(os.getenv('VAULT_PREVIOUS_KEYS','{}'))
        if not isinstance(keys,dict) or version in keys: raise RuntimeError('Invalid key ring')
        for v,k in keys.items():
            if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',v): raise RuntimeError('Invalid key version')
            Fernet(k.encode())
        keys[version]=key
        url=os.getenv('DATABASE_URL','sqlite:///./dev.db')
        if url.startswith('sqlite') and os.getenv('ALLOW_DEV_SQLITE')!='true':
            raise RuntimeError('SQLite requires explicit development adapter opt-in')
        if not url.startswith(('sqlite:','postgresql+psycopg:')): raise RuntimeError('Unsupported database adapter')
        return cls(url,key,enabled,tokens,version,keys)
