import hashlib,json,uuid
from datetime import date,time
from typing import Literal
from contextlib import asynccontextmanager
from fastapi import FastAPI,Depends,HTTPException,Header,Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.exceptions import RequestValidationError
from pydantic import BaseModel,ConfigDict,Field,StrictInt
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from api.config import Settings
from persistence.db import Store
from persistence.models import Account,BirthInput,Release,Run,Outcome,Stage,Audit,Job,VaultEntry,Redaction,ChartProvenanceVault
from governance.frozen import snapshot
from worker.jobs import uid,now
class Strict(BaseModel): model_config=ConfigDict(extra='forbid')
class BirthBody(Strict):
    local_date:str
    local_time:str
    civil_fold:StrictInt|None=Field(default=None,ge=0,le=1)
    time_precision:Literal['exact']
    place_query_or_selected_ref:str=Field(min_length=1,max_length=250)
    consent_version:Literal['M1-private-v1']
class StartBody(Strict): birth_input_id:str

def create_app(settings=None):
    settings=settings or Settings.load(); settings.__post_init__(); release=snapshot(); store=Store(settings)
    @asynccontextmanager
    async def lifespan(app):
        with store.session() as s: s.execute(select(Account).limit(1))
        yield
    app=FastAPI(title='Star Name private M3 (authority blocked)',lifespan=lifespan,docs_url=None,redoc_url=None,openapi_url=None); app.state.store=store
    @app.middleware('http')
    async def private_headers(request,call_next):
        response=await call_next(request)
        response.headers['Cache-Control']='no-store'
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['Referrer-Policy']='no-referrer'
        response.headers['X-Frame-Options']='DENY'
        response.headers['Content-Security-Policy']="default-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; script-src 'self'"
        return response
    @app.exception_handler(HTTPException)
    async def problem(request,exc):
        return JSONResponse(status_code=exc.status_code,content={'request_id':uid(),'problem':{'code':str(exc.detail),'message':str(exc.detail),'retryable':False}})
    @app.exception_handler(RequestValidationError)
    async def invalid(request,exc):
        return JSONResponse(status_code=422,content={'request_id':uid(),'problem':{'code':'INVALID_INPUT','message':'Request fields are invalid or unsupported','retryable':False}})
    def owner(authorization:str=Header(default='')):
        token=authorization.removeprefix('Bearer ') if authorization.startswith('Bearer ') else ''
        principal=settings.dev_tokens.get(token)
        if not principal: raise HTTPException(401,'AUTH_REQUIRED')
        with store.session() as s:
            if s.get(Redaction,principal): raise HTTPException(401,'AUTH_REQUIRED')
        return principal
    def envelope(data): return {'schema_version':'v1','request_id':uid(),'data':data}
    def owned(s,model,id,principal):
        obj=s.scalar(select(model).where(model.id==id,model.owner_id==principal))
        if not obj: raise HTTPException(404,'NOT_FOUND')
        return obj
    def birth_view(s,b):
        entry=s.get(VaultEntry,b.id)
        if entry is None: raise HTTPException(404,'NOT_FOUND')
        return {'birth_input_id':b.id,'revision':b.revision,'created_at':b.created_at,
                'input':json.loads(store.decrypt(entry))}
    def run_view(s,run):
        outcome=s.get(Outcome,run.id)
        stages=[json.loads(x.payload) for x in s.scalars(select(Stage).where(Stage.run_id==run.id).order_by(Stage.ordinal))]
        result=json.loads(outcome.payload) if outcome else None
        return {'run_id':run.id,'created_at':run.created_at,'delivery_status':'FINALIZED' if outcome else 'QUEUED',
            'terminal':result,'executed_stages':stages,'not_executed_stages':result['not_executed_stages'] if result else [],
            'versions':json.loads(s.get(Release,run.release_id).payload),'release_snapshot_digest':run.release_id,
            'canonical_available':False,'continuation_eligibility':{'eligible':False}}
    def write_owner(s,principal):
        from sqlalchemy import text
        if store.engine.dialect.name=='sqlite': s.execute(text('BEGIN IMMEDIATE'))
        if store.engine.dialect.name=='postgresql':
            from sqlalchemy.dialects.postgresql import insert
        else:
            from sqlalchemy.dialects.sqlite import insert
        s.execute(insert(Account).values(id=principal).on_conflict_do_nothing(index_elements=['id']))
        account=s.scalar(select(Account).where(Account.id==principal).with_for_update())
        if s.get(Redaction,principal): raise HTTPException(401,'AUTH_REQUIRED')
        return account
    @app.delete('/v1/account')
    def redact(principal=Depends(owner)):
        with store.session() as s:
            account=write_owner(s,principal)
            if not account: s.add(Account(id=principal)); s.flush()
            from sqlalchemy import delete
            s.execute(delete(VaultEntry).where(VaultEntry.birth_id.in_(select(BirthInput.id).where(BirthInput.owner_id==principal))))
            s.execute(delete(ChartProvenanceVault).where(ChartProvenanceVault.run_id.in_(select(Run.id).where(Run.owner_id==principal))))
            s.add(Redaction(owner_id=principal,created_at=now()))
            s.add(Audit(id=uid(),object_id=principal,action='ACCOUNT_PRIVATE_DATA_REDACTED',created_at=now()))
            s.commit()
        return envelope({'private_data_redacted':True,'immutable_history_retained':True,'credential_revoked':True})
    @app.get('/v1/determinations/{id}/chart-provenance')
    def provenance(id:str,principal=Depends(owner)):
        with store.session() as s:
            run=owned(s,Run,id,principal)
            entry=s.get(ChartProvenanceVault,run.id)
            if entry is None: raise HTTPException(404,'NOT_FOUND')
            return envelope(json.loads(store.decrypt(entry)))
    @app.get('/health')
    def health(): return {'status':'ok','mode':'development-private-M2'}
    @app.post('/v1/birth-inputs',status_code=201)
    def birth(body:BirthBody,principal=Depends(owner)):
        from determination.place_time import parse_local
        try:parse_local(body.model_dump())
        except ValueError:raise HTTPException(422,'INVALID_CIVIL_INPUT')
        with store.session() as s:
            if not write_owner(s,principal): s.add(Account(id=principal)); s.flush()
            b=BirthInput(id=uid(),owner_id=principal,logical_id=uid(),revision=1,
                encrypted='VAULT_SEPARATED_M2',created_at=now())
            s.add(b); s.flush()
            s.add(VaultEntry(birth_id=b.id,ciphertext=store.vault.encrypt(body.model_dump_json(exclude_none=True).encode()).decode(),key_version=store.key_version)); s.add(Audit(id=uid(),object_id=b.id,action='BIRTH_REVISION_CREATED',created_at=now())); s.commit()
            return envelope(birth_view(s,b))
    @app.get('/v1/birth-inputs')
    def births(principal=Depends(owner)):
        with store.session() as s: return envelope({'items':[{'birth_input_id':b.id,'revision':b.revision,'created_at':b.created_at} for b in s.scalars(select(BirthInput).where(BirthInput.owner_id==principal).order_by(BirthInput.created_at.desc(),BirthInput.id.desc()).limit(50))]})
    @app.get('/v1/birth-inputs/{id}')
    def read_birth(id:str,principal=Depends(owner)):
        with store.session() as s: return envelope(birth_view(s,owned(s,BirthInput,id,principal)))
    @app.post('/v1/determinations',status_code=202)
    def start(body:StartBody,idempotency_key:str=Header(alias='Idempotency-Key',min_length=1,max_length=200),principal=Depends(owner)):
        key=hashlib.sha256(idempotency_key.encode()).hexdigest()
        digest=hashlib.sha256(body.model_dump_json(exclude_none=True).encode()).hexdigest()
        def existing(s):
            run=s.scalar(select(Run).where(Run.owner_id==principal,Run.key_hash==key))
            if run and run.request_digest!=digest: raise HTTPException(409,'IDEMPOTENCY_CONFLICT')
            return run
        with store.session() as s:
            write_owner(s,principal)
            owned(s,BirthInput,body.birth_input_id,principal)
            run=existing(s)
            if not run:
                payload=json.dumps(release,sort_keys=True); rid=hashlib.sha256(payload.encode()).hexdigest()
                try:
                    if not s.get(Release,rid): s.add(Release(id=rid,payload=payload)); s.flush()
                    run=Run(id=uid(),owner_id=principal,birth_id=body.birth_input_id,release_id=rid,key_hash=key,request_digest=digest,created_at=now())
                    s.add(run); s.flush(); s.add(Job(id=uid(),run_id=run.id,state='QUEUED',attempts=0))
                    s.add(Audit(id=uid(),object_id=run.id,action='DETERMINATION_QUEUED',created_at=now())); s.commit()
                except IntegrityError:
                    s.rollback(); run=existing(s)
                    if not run: raise HTTPException(503,'RETRY_OPERATION')
            return envelope(run_view(s,run))
    @app.get('/v1/determinations/{id}')
    def status(id:str,principal=Depends(owner)):
        with store.session() as s: return envelope(run_view(s,owned(s,Run,id,principal)))
    @app.get('/v1/history')
    def history(limit:int=50,cursor:str|None=None,principal=Depends(owner)):
        if limit<1 or limit>50: raise HTTPException(422,'INVALID_LIMIT')
        with store.session() as s:
            q=select(Run).where(Run.owner_id==principal)
            if cursor:
                anchor=owned(s,Run,cursor,principal)
                from sqlalchemy import or_,and_
                q=q.where(or_(Run.created_at<anchor.created_at,and_(Run.created_at==anchor.created_at,Run.id<anchor.id)))
            rows=list(s.scalars(q.order_by(Run.created_at.desc(),Run.id.desc()).limit(limit+1)))
            return envelope({'items':[run_view(s,x) for x in rows[:limit]],'next_cursor':rows[limit-1].id if len(rows)>limit else None})
    @app.get('/v1/determinations/{id}/canonical')
    @app.get('/v1/determinations/{id}/starid')
    def gated(id:str,principal=Depends(owner)):
        with store.session() as s: owned(s,Run,id,principal)
        raise HTTPException(409,'CANONICAL_UNAVAILABLE')
    @app.api_route('/v1/{unavailable:path}',methods=['GET','POST','PATCH','PUT','DELETE'])
    def unavailable(unavailable:str):
        raise HTTPException(404,'NOT_FOUND')
    from api.source_access import install_source_routes
    install_source_routes(app)
    from pathlib import Path
    dist=Path(__file__).resolve().parents[1]/'web'/'dist'
    if dist.exists(): app.mount('/',StaticFiles(directory=dist,html=True),name='client')
    return app
