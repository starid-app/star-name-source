"""Public source routes serve only fixed, audited release objects; never user storage."""
import hashlib,json
from pathlib import Path
from fastapi import HTTPException
from fastapi.responses import FileResponse,HTMLResponse
ROOT=Path(__file__).resolve().parents[1]
RELEASE_ID='star-name-v1-phase151p-agpl'
ARCHIVE_NAME=RELEASE_ID+'.zip'
def verified_archive():
    manifest=json.loads((ROOT/'compliance/SOURCE_RELEASE_MANIFEST.json').read_text())
    path=ROOT/'compliance/releases'/ARCHIVE_NAME
    if manifest.get('release_id')!=RELEASE_ID or path.is_symlink():
        raise ValueError('source release identity mismatch')
    raw=path.read_bytes()
    if len(raw)!=manifest['archive_bytes'] or hashlib.sha256(raw).hexdigest()!=manifest['archive_sha256']:
        raise ValueError('source release integrity failure')
    from scripts.package_source import public_files
    actual={str(p.relative_to(ROOT)) for p in public_files(ROOT)}
    if actual!=set(manifest['source_tree_hashes']):raise ValueError('deployed source inventory mismatch')
    for name,digest in manifest['source_tree_hashes'].items():
        if name.startswith('/') or '..' in Path(name).parts:raise ValueError('source path invalid')
        source=ROOT/name
        if source.is_symlink() or hashlib.sha256(source.read_bytes()).hexdigest()!=digest:
            raise ValueError('source/deployed release mismatch')
    return path,manifest
def install_source_routes(app):
    @app.get('/source')
    def source_notice():
        return HTMLResponse('<!doctype html><html lang="en"><title>Star Name source</title><h1>Star Name source code</h1><p>Release: '+RELEASE_ID+'</p><p>AGPL-3.0-or-later. No warranty. You may redistribute under its terms. Downloads are free; user data and secrets are excluded.</p><a href="/source/'+ARCHIVE_NAME+'">Download complete corresponding source</a><p><a href="/source/license">License</a> · <a href="/source/notices">Third-party notices and GeoNames attribution</a></p></html>')
    @app.get('/source/'+ARCHIVE_NAME)
    def source_download():
        try:path,manifest=verified_archive()
        except (OSError,ValueError,KeyError):raise HTTPException(503,'SOURCE_RELEASE_UNAVAILABLE')
        return FileResponse(path,media_type='application/zip',filename=ARCHIVE_NAME,headers={'X-Source-Release':RELEASE_ID,'X-Source-SHA256':manifest['archive_sha256']})
    @app.get('/source/license')
    def license_text():return FileResponse(ROOT/'LICENSE',media_type='text/plain')
    @app.get('/source/notices')
    def notices():return FileResponse(ROOT/'compliance/THIRD_PARTY_NOTICES.md',media_type='text/plain')
