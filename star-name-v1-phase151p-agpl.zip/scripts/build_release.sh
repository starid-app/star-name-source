#!/bin/sh
set -eu
# Requires Python 3.12, gcc/g++, Python headers, pip/setuptools/wheel and Node/npm.
# Install pinned dependencies, then build the exact bundled Swiss source; do not use a new provider.
python -m pip install -r requirements.lock
CC=gcc CXX=g++ python -m pip install --no-deps --no-build-isolation vendor/pyswisseph-2.10.3.2.tar.gz
(cd web && npm ci && npm run build)
python scripts/package_source.py .source-release
mkdir -p compliance/releases
cp .source-release/star-name-v1-phase151p-agpl.zip compliance/releases/
cp .source-release/SOURCE_RELEASE_MANIFEST.json compliance/
python -m pytest
# Generate credentials ONLY in private local storage when running development:
# python scripts/dev_setup.py; python -m alembic upgrade head
# Public deployment is gated separately; production authentication is not implemented.
