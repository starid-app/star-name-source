"""Private operator ledger export/reapply. Run before exposing a restored database."""
import argparse,json,os
from api.config import Settings
from persistence.db import Store
from persistence.privacy import export_tombstones,reapply_tombstones
p=argparse.ArgumentParser();p.add_argument('action',choices=['export','reapply']);p.add_argument('ledger');args=p.parse_args()
store=Store(Settings.load())
if args.action=='export':
    # Refuse overwrite; operator publishes this private checkpoint to independent protected storage.
    fd=os.open(args.ledger,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:json.dump(export_tombstones(store),f)
else:
    with open(args.ledger) as f:reapply_tombstones(store,json.load(f))
print('PRIVATE_LEDGER_OPERATION_COMPLETE')
