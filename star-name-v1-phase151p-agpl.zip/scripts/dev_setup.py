import secrets
from pathlib import Path
from cryptography.fernet import Fernet
p=Path('.env')
if p.exists(): raise SystemExit('.env already exists; preserved')
p.write_text('APP_ENV=development\nDEV_AUTH=true\nALLOW_DEV_SQLITE=true\nDATABASE_URL=sqlite:///./dev.db\nVAULT_KEY='+Fernet.generate_key().decode()+'\nDEV_TOKENS='+secrets.token_urlsafe(32)+':local-owner\nPOSTGRES_PASSWORD='+secrets.token_hex(24)+'\n')
p.chmod(0o600)
print('Created private .env. Use its development token in the client.')
