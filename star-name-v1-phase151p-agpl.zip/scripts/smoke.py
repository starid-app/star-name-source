"""Separate-process local acceptance with only fresh synthetic transport input."""
import json,os,subprocess,sys,tempfile,time
from pathlib import Path
import httpx
from cryptography.fernet import Fernet
root=Path(__file__).resolve().parents[1]
client=httpx.Client(trust_env=False)
result={'command':'python scripts/smoke.py','checks':[]}
with tempfile.TemporaryDirectory() as directory:
    env={**os.environ,'APP_ENV':'development','DEV_AUTH':'true','DEV_TOKENS':'s'*32+':synthetic-smoke-owner','VAULT_KEY':Fernet.generate_key().decode(),'ALLOW_DEV_SQLITE':'true','DATABASE_URL':'sqlite:///'+directory+'/smoke.db'}
    def command(*args):
        subprocess.run([sys.executable,*args],cwd=root,env=env,check=True,capture_output=True)
    command('-m','alembic','upgrade','head')
    result['checks'].append('migration_seed')
    process=None
    vite=None
    def launch():
        p=subprocess.Popen([sys.executable,'-m','uvicorn','api.asgi:app','--host','127.0.0.1','--port','8001','--no-access-log'],cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(100):
            if p.poll() is not None:raise RuntimeError('API startup failed')
            try:
                if client.get('http://127.0.0.1:8001/health').status_code==200:return p
            except httpx.ConnectError:pass
            time.sleep(.05)
        p.terminate();raise RuntimeError('API startup timeout')
    try:
        process=launch();base='http://127.0.0.1:8001';headers={'Authorization':'Bearer '+'s'*32}
        assert client.get(base+'/').status_code==200
        result['checks'].append('built_client_http_200')
        vite=subprocess.Popen(['npm','run','dev','--','--port','5174','--strictPort'],cwd=root/'web',env={**env,'VITE_API_ORIGIN':base},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(100):
            if vite.poll() is not None:raise RuntimeError('Client dev-server startup failed')
            try:
                if client.get('http://127.0.0.1:5174').status_code==200:break
            except httpx.ConnectError:pass
            time.sleep(.05)
        assert client.get('http://127.0.0.1:5174/src/main.tsx').status_code==200
        assert client.get('http://127.0.0.1:5174/v1/history',headers=headers).status_code==200
        result['checks'].append('client_dev_server_and_private_api_proxy')
        response=client.post(base+'/v1/birth-inputs',headers=headers,json={'local_date':'2001-02-03','local_time':'04:05:06','time_precision':'exact','place_query_or_selected_ref':'Synthetic smoke place','consent_version':'M1-private-v1'})
        assert response.status_code==201;birth=response.json()['data']['birth_input_id']
        h={**headers,'Idempotency-Key':'synthetic-smoke'}
        response=client.post(base+'/v1/determinations',headers=h,json={'birth_input_id':birth})
        assert response.status_code==202;run=response.json()['data']['run_id']
        assert response.json()['data']['delivery_status']=='QUEUED'
        result['checks'].append('private_submit_queued')
        command('-m','worker.main','--once')
        status=client.get(base+'/v1/determinations/'+run,headers=headers).json()['data']
        assert status['terminal']['exact_code']=='INPUT / CHART UNRESOLVED'
        assert status['delivery_status']=='FINALIZED' and status['canonical_available'] is False
        result['checks'].append('separate_worker_exact_stop')
        provenance=client.get(base+'/v1/determinations/'+run+'/chart-provenance',headers=headers).json()['data']
        assert provenance['birth_input_revision_ref']==birth
        assert provenance['chart_status']=='NOT_EXECUTED'
        assert provenance['civil_time']['utc_instant'] is None
        result['checks'].append('m3_private_fail_closed_provenance')
        command('-m','worker.main','--once')
        assert client.get(base+'/v1/determinations/'+run,headers=headers).json()['data']==status
        result['checks'].append('worker_restart_retry_stable')
        process.terminate();process.wait(timeout=10);process=launch()
        assert client.get(base+'/v1/determinations/'+run,headers=headers).json()['data']==status
        assert client.post(base+'/v1/determinations',headers=h,json={'birth_input_id':birth}).json()['data']==status
        assert client.get(base+'/v1/history',headers=headers).json()['data']['items']==[status]
        assert client.get(base+'/v1/determinations/'+run+'/chart-provenance',headers=headers).json()['data']==provenance
        result['checks'].append('api_process_restart_refresh_history_stable')
        for suffix in ['canonical','starid']:
            assert client.get(base+'/v1/determinations/'+run+'/'+suffix,headers=headers).status_code==409
        assert client.get(base+'/v1/history').status_code==401
        assert client.post(base+'/v1/admin/releases',json={'enabled':True},headers=headers).status_code==404
        result['checks'].append('private_and_disabled_endpoints')
        result['status']='PASS';result['pass_count']=len(result['checks']);print(json.dumps(result,indent=2))
    finally:
        if vite:vite.terminate();vite.wait(timeout=10)
        if process:process.terminate();process.wait(timeout=10)
