"""Package only public source. Never walk databases or private runtime storage."""
import hashlib,json,zipfile,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RELEASE_ID='star-name-v1-phase151p-agpl'
PUBLIC_DIRS={'api','worker','determination','persistence','governance','migrations','scripts','tests','docs','compliance','resources','authority','vendor','web'}
PUBLIC_FILES={'.env.example','.dockerignore','.gitignore','Dockerfile','compose.yaml','alembic.ini','pytest.ini','requirements.lock','README.md','LICENSE','LICENSING.md'}
def public_files(root=ROOT):
    files=[]
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root);parts=rel.parts
        if any(p in {'node_modules','__pycache__','.pytest_cache','.venv','dist','releases'} for p in parts):continue
        if path.is_symlink():raise ValueError('symlinks forbidden in source tree: '+str(rel))
        if not path.is_file():continue
        if str(rel)=='compliance/SOURCE_RELEASE_MANIFEST.json':continue
        if len(parts)==1 and str(rel) not in PUBLIC_FILES:continue
        if len(parts)>1 and parts[0] not in PUBLIC_DIRS:continue
        if path.name=='.env' or path.suffix in {'.db','.sqlite','.sqlite3','.log','.pem','.key','.p12','.pfx','.crt','.pyc'}:raise ValueError('private/runtime file rejected: '+str(rel))
        files.append(path)
    return files
def package(destination):
    destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
    files=public_files();hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    archive=destination/(RELEASE_ID+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:
            info=zipfile.ZipInfo(str(p.relative_to(ROOT)),(2026,10,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o100755 if p.name.endswith('.sh') else 0o100644)<<16;z.writestr(info,p.read_bytes())
    manifest={'release_id':RELEASE_ID,'license':'AGPL-3.0-or-later','publicly_published':False,'source_path':'/source/'+archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source_tree_hashes':hashes,'excluded':'source ZIP and detached manifest, compiled browser output, dependency installs/caches, private runtime state','source_only_distribution':True}
    (destination/'SOURCE_RELEASE_MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');return manifest
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('destination');args=parser.parse_args();package(args.destination)
