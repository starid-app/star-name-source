"""Run real browser acceptance, preserving missing-browser failure without simulating UI."""
import os,sys,tempfile,subprocess,time,json
from pathlib import Path
from cryptography.fernet import Fernet
import httpx
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as directory:
    env={**os.environ,'APP_ENV':'development','DEV_AUTH':'true','DEV_TOKENS':'u'*32+':ui-owner,'+'v'*32+':ui-other','VAULT_KEY':Fernet.generate_key().decode(),'DATABASE_URL':'sqlite:///'+directory+'/ui.db','ALLOW_DEV_SQLITE':'true','UI_DEV_TOKEN':'u'*32,'UI_OTHER_DEV_TOKEN':'v'*32,'UI_BASE_URL':'http://127.0.0.1:8002'}
    subprocess.run([sys.executable,'-m','alembic','upgrade','head'],cwd=root,env=env,check=True,capture_output=True)
    api=subprocess.Popen([sys.executable,'-m','uvicorn','api.asgi:app','--host','127.0.0.1','--port','8002','--no-access-log'],cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    worker=subprocess.Popen([sys.executable,'-m','worker.main'],cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        with httpx.Client(trust_env=False) as client:
            for i in range(100):
                if api.poll() is not None:raise RuntimeError('API failed')
                try:
                    if client.get(env['UI_BASE_URL']+'/health').status_code==200:break
                except httpx.ConnectError:pass
                time.sleep(.05)
            else:raise RuntimeError('API timeout')
        result=subprocess.run(['node','browser-smoke.mjs'],cwd=root/'web',env=env,capture_output=True,text=True,timeout=60)
        print(json.dumps({'executed_api_worker':True,'browser_exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'browser_assertions_executed':result.returncode==0},indent=2))
        sys.exit(result.returncode)
    finally:
        api.terminate();worker.terminate();api.wait(timeout=10);worker.wait(timeout=10)
