# Third-party notices
Star Name application licensing is specified in LICENSE and LICENSING.md. These third-party notices preserve independent grants; they do not certify public deployment.

PySwissEph 2.10.3.2: Copyright 2007-2023 Stanislas Marquis. AGPL-3.0-or-later; complete license in compliance/AGPL-3.0.txt. Exact source retained in vendor/pyswisseph-2.10.3.2.tar.gz. Swephelp: Copyright 2007-2020 Stanislas Marquis, GPL-2.0-or-later; preserve full headers and GPL text. This combined release elects the available GPLv3-or-later option; full GPLv3 text is in compliance/GPL-3.0.txt. Original headers and GPLv2 text are retained.

Swiss Ephemeris: Copyright 1997-2021 Astrodienst AG, Switzerland, as retained source notice states. Authors Dieter Koch and Alois Treindl. Dual AGPL/professional conditions in compliance/SWISS_EPHEMERIS_LICENSE.txt apply; these names are notices, not endorsements or promotion. Exact resources sepl_18.se1 and semo_18.se1 retained unchanged. No warranty.

GeoNames geographical data: https://www.geonames.org/ under https://creativecommons.org/licenses/by/4.0/. Data provided as is without warranty of accuracy, timeliness or completeness. Changes: snapshot extraction, deterministic filtering, hierarchy joins, normalized lookup and conversion to Star Name JSON schema; 29037 admitted records. Coordinates remain source representative points. Contains Ordnance Survey data Crown copyright and database right 2010; contains public sector information licensed under Open Government Licence v1.0, as GeoNames supplied source credit states. No GeoNames endorsement is implied. Preserve supplied credits and license references when sharing adapted database records; do not impose additional restrictions on CC-licensed data.

IANA time-zone code/data 2026e: public domain except individually identified BSD-derived ancillary files; retained LICENSE in compliance/IANA_LICENSE.txt. Frozen zic/TZif provenance preserved.

SQLite bundled 3.39.2: public-domain dedication in sqlite3.c; retain original header. Native executable additionally links system libstdc++, libgcc_s, libm and libc; runtime license exceptions and actual container distribution must be checked at release. Exact installed Python metadata/notices retained under compliance/runtime_metadata. Browser assets and dependencies have their own licenses; see package-lock supplement.
