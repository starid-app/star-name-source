# Authenticated Phase150P requirements

# Source availability specification — pending license election
Before any AGPL-covered public service release: prepare a release-matched source archive including Star Name covered source, exact PySwissEph/libswe/Swephelp sources, necessary build/install/control scripts, dependency/license notices and exact resource/data provenance. Verify rebuilding against frozen authority and ensure no private birth data, credentials, keys or personal records enter the archive. Archive hashes, build version and deployed version must match.
Provide a prominent source-access link to every network user where AGPL section 13 applies, with no charge for download. For conveyed binaries satisfy AGPL sections 4-6 as applicable. Test successful download and complete source independently. Add actual endpoint/link only after authority to license and publish project source exists. No placeholder endpoint is evidence of compliance. No public offer is claimed here.

# Deployment analysis
Scope: Star Name serves users over a network; its Python server/worker imports the pinned native PySwissEph extension and calculates charts using the two frozen Swiss resources, local GeoNames registry and IANA TZif files. It is integrated in-process code, not an independent public ephemeris service. No existing project-wide license, accepted AGPL election, signed professional agreement or independent PySwissEph permission was found in supplied project evidence.

Running an unmodified program privately and modifying privately are allowed under AGPL section 2; mere network interaction is not itself conveyance. That distinction does not automatically exempt this integrated public application: Swiss publisher terms require election before public service, and application linking/combination must satisfy the selected grant. Do not claim AGPL section 13 applies to every unmodified executable merely because it is on a server, nor assume using an unmodified library eliminates the integrated project's obligations.

For an AGPL-compliant release, the supported consequence is project coverage under AGPL or a compatible license as publisher terms require, compatible treatment of linked Swephelp under GPLv3, retained notices, and complete corresponding source offered prominently without charge to network users where section 13 applies. Include wrapper/library source, application source and necessary build/install scripts; exclude private user data, keys and secrets. Charging for service is not forbidden. A source endpoint or link without a legally permitted, complete and release-matched source package is insufficient.

The professional route requires an authenticated signed project-specific agreement for Swiss code/resources plus separately established wrapper/helper rights or a demonstrably compliant covered-work arrangement. Buying a Swiss license alone is not a wrapper AGPL exemption. No purchase, substitute wrapper, restructuring or provider change was performed.

The handoff prohibits an invented business model or unilateral project relicensing. This executor therefore records the necessary consequence and prepares notices/source-release specification, but does not elect or publish the owner's project license. Licensing permission is not impossible or generally unknown; concrete project election and compliance evidence are absent. Terminal is compliance action required. No affirmative E4 certificate is issued; rights for intended public deployment are not admitted.

Redistributing containers/wheels/binaries is a separate conveyance event: check corresponding source, downstream notices, installation information where applicable and dependency-specific duties (including LGPL psycopg). Local third-party source retention is diagnostic evidence and not a public source offer. The result bundle is an engineering handoff, not a certified public binary distribution or deployment.

## Exact inherited checklist

```csv
id,requirement,status
C01,Exact Phase149 archive and all 731 payloads verified,PASS
C02,Exact rights inventory and preserved notices prepared,PASS
C03,Owner project license election / covered-work scope authenticated,PENDING
C04,AGPL source licensing and compatibility complete OR exact alternate grants authenticated,PENDING
C05,Release-matched corresponding source and build scripts complete,PENDING_IF_AGPL
C06,Prominent no-charge remote source mechanism exercised,PENDING_IF_AGPL
C07,Actual deployment binary/container dependency notices and conveyance obligations audited,PENDING_RELEASE
C08,M3 gate remains false and E4 remains missing,PASS
C09,M4 and downstream identity paths remain disabled,PASS
C10,GeoNames attribution available for release UI/data sharing,NOTICE_PREPARED_UI_PENDING
C11,Fresh product chart success tests,NOT_RUN_GATE_CLOSED
```

Phase151P owner Route A now supplies election and project coverage. Publication and actual deployment identity are not claimed. No requirements were broadened or substituted.
