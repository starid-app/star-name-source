import {defineConfig} from 'vite'; export default defineConfig({server:{proxy:{'/v1':process.env.VITE_API_ORIGIN||'http://127.0.0.1:8000'}}});
