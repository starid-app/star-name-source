from pathlib import Path
import zipfile,json,hashlib,re,platform,subprocess
R=Path('results');S=R/'star-name-v1';A=R/'authority/source';G=S/'governance'
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def rows(name):return [s.split('\t') for s in (A/name).read_text().splitlines() if s and not s.startswith('#')]
a1={r[0]:r for r in rows('admin1CodesASCII.txt')};a2={r[0]:r for r in rows('admin2Codes.txt')};countries={r[0]:r[4] for r in rows('countryInfo.txt')}
allowed={'PPL','PPLA','PPLA2','PPLA3','PPLA4','PPLC'};records=[];rejected={}
with zipfile.ZipFile(A/'cities15000.zip') as z:raw=z.read('cities15000.txt')
for line in raw.decode().splitlines():
 r=line.split('\t');admin=a1.get(r[8]+'.'+r[10]);county=a2.get(r[8]+'.'+r[10]+'.'+r[11])
 reason=None
 if r[6]!='P' or r[7] not in allowed:reason='FEATURE_UNSUPPORTED'
 elif not admin or r[8] not in countries:reason='HIERARCHY_MISSING'
 elif not all(re.fullmatch(r'-?\d+\.\d{4,7}',x) for x in r[4:6]):reason='COORDINATE_RESOLUTION_INSUFFICIENT'
 elif not (S/'resources/timezones'/r[17]).is_file():reason='TIMEZONE_MAPPING_UNSUPPORTED'
 if reason:rejected[reason]=rejected.get(reason,0)+1;continue
 records.append({'id':'geonames:'+r[0],'name':r[1],'ascii_name':r[2],'country_code':r[8],'country_name':countries[r[8]],'admin1_code':r[10],'admin1_name':admin[1],'admin1_ascii':admin[2],'admin2_code':r[11] or None,'admin2_name':county[1] if county else None,'latitude':r[4],'longitude':r[5],'datum':'WGS84','feature_class':r[6],'feature_code':r[7],'timezone_identifier':r[17],'modified_date':r[18],'record_sha256':sha(line.encode()),'coordinate_basis':'LOCALITY_REPRESENTATIVE_POINT','accuracy_meters':None,'precision':{'latitude_decimal_places':len(r[4].split('.')[1]),'longitude_decimal_places':len(r[5].split('.')[1]),'positional_accuracy':'NOT_PROVIDED_BY_PROVIDER'},'provenance':'GeoNames cities15000 source row; original object SHA256 in place lock; timezone from column 18'})
records.sort(key=lambda x:int(x['id'].split(':')[1]));obj={'schema_version':'place-registry-149p','provider':'GeoNames','snapshot':'content-addressed-acquisition-2026-10-01','records':records}
p=S/'resources/places.json';j(p,obj)
place={'schema_version':'place-authority-lock-149p','admitted':True,'provider':'GeoNames','dataset_version':obj['snapshot'],'dataset_path':'resources/places.json','dataset_sha256':sha(p.read_bytes()),'original_objects':{n:sha((A/n).read_bytes()) for n in ['cities15000.zip','admin1CodesASCII.txt','admin2Codes.txt','countryInfo.txt','readme.txt','featureCodes_en.txt']},'source_text_sha256':sha(raw),'coordinate_rule':'CITY_REPRESENTATIVE_V1','rights':'GeoNames CC BY 4.0; attribution retained; no warranty','record_count':len(records),'excluded_counts':rejected,'source_url':'https://download.geonames.org/export/dump/'}
timefiles={str(p.relative_to(S/'resources/timezones')):sha(p.read_bytes()) for p in sorted((S/'resources/timezones').rglob('*')) if p.is_file()}
time={'schema_version':'civil-authority-lock-149p','admitted':True,'provider':'IANA','dataset_version':'2026e','archive_sha256':sha((A/'tzdata2026e.tar.gz').read_bytes()),'code_archive_sha256':sha((A/'tzcode2026e.tar.gz').read_bytes()),'version_file':Path('tzbuild/version').read_text().strip(),'tzdata_zi_sha256':sha(Path('tzbuild/tzdata.zi').read_bytes()),'zic_sha256':sha(Path('tzbuild/zic').read_bytes()),'build_command':'make zic tzdata.zi CC=cc; zic -b fat -d OUTPUT tzdata.zi','compiler':subprocess.run(['cc','--version'],capture_output=True,text=True).stdout.splitlines()[0],'python':platform.python_version(),'loader':'stdlib zoneinfo.ZoneInfo.from_file; verified TZif bytes only','supported_utc_start':'1970-01-01T00:00:00Z','supported_utc_end_exclusive':'2027-01-01T00:00:00Z','dataset_path':'resources/timezones','tzif_sha256':timefiles,'rights':'IANA public-domain source; LICENSE retained'}
for n,x in [('PLACE_AUTHORITY_LOCK.json',place),('CIVIL_TIME_AUTHORITY_LOCK.json',time)]:j(R/n,x);j(G/n,x)
j(R/'AUTHORITY_RECORD_AUDIT.json',{'admitted':len(records),'excluded':rejected,'ottawa':[r for r in records if r['name']=='Ottawa']})
print('admitted',len(records),'zones',len(timefiles),'rejected',rejected)
