import hashlib,json,uuid
from datetime import datetime,timezone
from sqlalchemy import select,text
from persistence.models import Job,Run,Release,Outcome,Stage,Audit,Outbox,VaultEntry,Redaction,Account,ChartProvenanceVault
from determination.chart_guard import guard
from governance.frozen import snapshot

def uid(): return str(uuid.uuid4())
def now(): return datetime.now(timezone.utc).isoformat()
def process_one(store,run_id=None):
    with store.session() as s:
        # Whole job is one transaction: crash rolls back; restart sees durable QUEUED.
        if store.engine.dialect.name=='sqlite': s.execute(text('BEGIN IMMEDIATE'))
        q=select(Job).where(Job.state=='QUEUED')
        if run_id: q=q.where(Job.run_id==run_id)
        job=s.scalar(q.order_by(Job.id).limit(1).with_for_update(skip_locked=True))
        if not job: return False
        run=s.get(Run,job.run_id); release=json.loads(s.get(Release,run.release_id).payload)
        if hashlib.sha256(json.dumps(release,sort_keys=True).encode()).hexdigest()!=run.release_id or release!=snapshot():
            raise RuntimeError('Pinned release integrity failure')
        if not s.get(Outcome,run.id):
            # Serialize against account redaction; never reconstruct deleted input.
            s.scalar(select(Account).where(Account.id==run.owner_id).with_for_update())
            vault=s.get(VaultEntry,run.birth_id)
            private_input=json.loads(store.decrypt(vault)) if vault and not s.get(Redaction,run.owner_id) else None
            result=guard(release,private_input)
            if private_input is not None:
                from determination.m3 import evaluate
                provenance=evaluate(private_input)
                provenance.update(birth_input_revision_ref=run.birth_id,run_id=run.id,release_snapshot_digest=run.release_id)
                s.add(ChartProvenanceVault(run_id=run.id,ciphertext=store.vault.encrypt(json.dumps(provenance,sort_keys=True).encode()).decode(),key_version=store.key_version))
            result['release_snapshot_digest']=run.release_id
            for ordinal,kind in [(0,'VERSION_LOCK'),(1,'INPUT_CHART_PREREQUISITE_GUARD')]:
                payload={'ordinal':ordinal,'kind':kind,'status':'STOP' if ordinal==1 else 'SUCCESS',
                    'input_ref':run.birth_id,'output_ref':run.release_id if ordinal==0 else 'INPUT / CHART UNRESOLVED',
                    'release_snapshot_digest':run.release_id,'resource_ref':'ABSENT' if ordinal==1 else None}
                s.add(Stage(id=uid(),run_id=run.id,ordinal=ordinal,payload=json.dumps(payload)))
            s.add(Outcome(run_id=run.id,payload=json.dumps(result,sort_keys=True)))
            s.add(Audit(id=uid(),object_id=run.id,action='FINALIZED_INPUT_CHART_STOP',created_at=now()))
            s.add(Outbox(id=uid(),run_id=run.id,kind='PRIVATE_STATUS_FINALIZED'))
        job.state='FINALIZED'; job.attempts+=1; s.commit()
        return True
