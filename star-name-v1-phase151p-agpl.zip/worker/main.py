import argparse,time
from api.config import Settings
from persistence.db import Store
from worker.jobs import process_one
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--once',action='store_true'); args=p.parse_args()
    store=Store(Settings.load())
    while True:
        try:
            worked=process_one(store)
        except Exception:
            # No exception message or SQL parameters: durable transaction rolls back.
            import logging
            logging.getLogger('starname.worker').error('WORKER_TRANSACTION_FAILED')
            if args.once: raise SystemExit(1)
            time.sleep(2)
            continue
        if args.once: break
        if not worked: time.sleep(1)
