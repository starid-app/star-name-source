import csv,hashlib,json
from pathlib import Path
ROOT=Path(__file__).parent
MANIFEST_BYTES=(ROOT/'capabilities.json').read_bytes()
MANIFEST_HASH=hashlib.sha256(MANIFEST_BYTES).hexdigest()
EXPECTED_MANIFEST_HASH='c30e0747e274a9ba4a96c679232deec69a27c309685c60168451be903bc8493f'
EXPECTED_TERMINALS_HASH='8b068b48ac477a75a1fb56554e3e1b0dab2bdbbccbca8b10f654ffde8d3933ff'
TERMINALS={r['exact_internal_terminal']:r for r in csv.DictReader((ROOT/'terminals.csv').open())}
STOP='INPUT / CHART UNRESOLVED'
def snapshot():
    if MANIFEST_HASH!=EXPECTED_MANIFEST_HASH or hashlib.sha256((ROOT/'terminals.csv').read_bytes()).hexdigest()!=EXPECTED_TERMINALS_HASH:
        raise RuntimeError('Frozen governance byte identity mismatch')
    data=json.loads(MANIFEST_BYTES)
    if any(v is not False for v in data['capabilities'].values()):
        raise RuntimeError('M0/M1 capability activation forbidden')
    data['capability_digest']=MANIFEST_HASH
    data['status_mapping_digest']=hashlib.sha256((ROOT/'terminals.csv').read_bytes()).hexdigest()
    root=ROOT.parent
    files=sorted(p for folder in ['api','worker','determination','persistence','governance','migrations'] for p in (root/folder).rglob('*') if p.is_file() and p.suffix in ['.py','.json','.csv'])
    data['executable_digest']=hashlib.sha256(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},sort_keys=True).encode()).hexdigest()
    from determination.m3 import authority_lock,EXPECTED_LOCK_SHA256
    authority_lock()
    data['m3_authority_lock_sha256']=EXPECTED_LOCK_SHA256
    data['m3_positive_numerical_activation']=False
    data['permission_activation_manifest']='NO_POSITIVE_AUTHORITY'
    return data
def can_execute(path,release):
    # This build contains no authorized positive executor, regardless of caller flags.
    return False
