# Phase148P numerical restoration

The original Phase11 sepl_18.se1 and semo_18.se1 bytes are installed under resources/ephe. Their exact approved SHA-256 values are in governance/M3_NUMERICAL_AUTHORITY_LOCK.json and determination/e1_restored.py. The accepted RC3 numerical modules are preserved under determination/historical_rc3; its original timezone module is excluded. No semantic pipeline is imported.

Install requirements.lock for the inherited application and requirements-numerical.txt for the exact accepted PySwissEph package. The original backend is 2.10.03. Current binary build identity is runtime evidence, not an invented original binary certificate. resources and runtime identity are rechecked; caller-supplied paths/hashes and environment toggles confer no admission.

The product adapter remains disabled: P1 and P2 require owner policy, E2 requires admitted place/coordinate/zone records, E3 requires admitted civil-time rule bytes, and E4 requires applicable admission/rights and validation. No host timezone, geocoder, approximate centroid or successful chart is supplied to the worker. API outcomes remain INPUT / CHART UNRESOLVED.

The isolated historical_numerical_regression helper accepts already-authenticated fixture UTC/coordinates and reproduces RC3 numerical records/fingerprints only. It is not called by the product adapter. Swiss process-global numerical calls through it are serialized, use the exact pinned package, hash preflight, UTC-year range guard and strict returned-mode checks. Errors do not produce a result.

The nominal 1800–2399 year scope is not a guarantee every instant is available from these two files. Fresh testing observed Moshier fallback at 1800-01-01 00:00 UTC because the backend requested sepl_12.se1. That instant is rejected; no extra file or date policy is introduced.
