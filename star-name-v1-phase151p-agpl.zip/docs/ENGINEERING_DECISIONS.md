# M0/M1 engineering choices

REQUIRED: inherited exact terminal vocabulary; fail-closed resource/authority boundary; no positive paths; immutable private input/outcome/version history; server-owned determination; owner isolation; idempotent durable job transaction; no Expression feedback.

ENGINEERING: React/TypeScript + Vite, FastAPI/Pydantic, SQLAlchemy/Alembic, transactional jobs/outbox and pytest follow Phase142P. PostgreSQL remains the configured relational target. Local SQLite is explicitly opted-in development only because PostgreSQL/container binaries are absent. This substitution changes no methodology. Worker transaction is short and does no numerical work or network I/O. No lease is needed for this atomic guard; later expensive stages require checkpoint/lease design before activation.

Single server-held Fernet key encrypts all development birth JSON. This is a local adapter, not the recommended production owner-key/KMS implementation. Local development bearer credentials require strong generated tokens; APP_ENV=production startup is blocked. No production authentication or public release is claimed.

A versioned input revision table exists and raw SQL/ORM cannot overwrite it. Create-only API supplies revision 1; later revision editing must introduce predecessor/logical identity validation through a separate milestone. Schema downgrade is intentionally unavailable because silent history destruction is forbidden.

The immutable ReleaseSnapshot stores master, methodology label, exact status mapping hash, capability bytes hash, executable source digest, permission/activation disposition, and explicit absent resource fields. The internal metadata digest is not an authoritative ChartFingerprint or TargetFingerprint. No such fingerprint is computed.

Exact stage ordinals follow Phase142P. Guard processing is at the first missing mandatory prerequisite (input stage 1); it does not certify civil-time interpretation to reach chart stage 2. Strict numerical chart success remains absent. Later numerical blockers are unevaluated, not later executed failures. Application status/privacy infrastructure operates around the determination trace; it is not a claimed successful methodology stage 28–30.

Outbox is internal and contains only opaque run reference plus generic status-event kind. No external messages/notifications are sent. Audit is a private append-only operational ledger with pseudonymous object references; normative signed/hash-linked authority ledger is deferred because this build performs no authority changes.

Limitations before broader use: managed auth/TLS; per-owner keys/rotation; deletion and retention/backup rehearsal; bounded rate limits and body limits; PostgreSQL/concurrent integration; reviewed container image digests; operational lease/attempt/backoff telemetry for long-running stages. None permits positive methodology activation.
