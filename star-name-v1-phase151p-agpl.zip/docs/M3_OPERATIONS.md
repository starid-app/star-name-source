# M3 authority-blocked runtime

Run python -m alembic upgrade head (0003), python -m pytest -q, npm ci --offline / npm run build in web, then python scripts/smoke.py. PostgreSQL opt-in remains M2_TEST_DATABASE_URL. Do not run development authentication/SQLite in production.

The authority lock is an immutable artifact pinned in determination/m3.py and release snapshots. It cannot enable calculation. Recovery of missing authority needs a reviewed new version and real integration tests. No environment toggle activates it. The new private provenance endpoint is documented in M3_CHART_PROVENANCE_SCHEMA.md. Redaction and key rotation include provenance ciphertext.

Older queued runs require their old pinned executable; retain the provided original evidence archive. Finalized old outcomes remain unchanged. Deployment requires still-blocked production checks. Do not treat a library installation or synthetic byte/flag fixture as approved ephemeris authority.
