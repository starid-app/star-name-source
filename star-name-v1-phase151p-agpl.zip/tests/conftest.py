import os
import pytest
from cryptography.fernet import Fernet
from alembic.config import Config
from alembic import command
from fastapi.testclient import TestClient
from api.main import create_app
from api.config import Settings
@pytest.fixture
def local(tmp_path,monkeypatch):
    values={'APP_ENV':'development','DEV_AUTH':'true','DEV_TOKENS':'a'*32+':owner-a,'+'b'*32+':owner-b','VAULT_KEY':Fernet.generate_key().decode(),'ALLOW_DEV_SQLITE':'true','DATABASE_URL':'sqlite:///'+str(tmp_path/'test.db')}
    for k,v in values.items():monkeypatch.setenv(k,v)
    command.upgrade(Config('alembic.ini'),'head')
    app=create_app(Settings.load())
    with TestClient(app) as client:yield client,app.state.store
