"""Opt-in real PostgreSQL acceptance; never substitutes a SQLite execution."""
import os,uuid
from concurrent.futures import ThreadPoolExecutor
import pytest
from sqlalchemy import create_engine,text,select,func
from sqlalchemy.engine import make_url
from sqlalchemy.exc import DatabaseError,IntegrityError
from alembic.config import Config
from alembic import command
from fastapi.testclient import TestClient
from cryptography.fernet import Fernet
from api.config import Settings
from api.main import create_app
from persistence.models import Outcome,Stage,Audit,Outbox,Job
from worker.jobs import process_one
from tests.test_m1 import A,B,birth,start

@pytest.mark.skipif(not os.getenv('M2_TEST_DATABASE_URL'),reason='Actual PostgreSQL server/authorized test URL unavailable')
def test_real_postgresql_runtime(monkeypatch):
    original=make_url(os.environ['M2_TEST_DATABASE_URL'])
    assert original.drivername=='postgresql+psycopg'
    schema='m2_test_'+uuid.uuid4().hex
    admin=create_engine(original,hide_parameters=True)
    with admin.begin() as conn:conn.execute(text(f'CREATE SCHEMA {schema}'))
    try:
        url=original.update_query_dict({'options':'-csearch_path='+schema}).render_as_string(hide_password=False)
        for k,v in {'APP_ENV':'development','DEV_AUTH':'true','DEV_TOKENS':'a'*32+':owner-a,'+'b'*32+':owner-b','VAULT_KEY':Fernet.generate_key().decode(),'DATABASE_URL':url}.items():monkeypatch.setenv(k,v)
        command.upgrade(Config('alembic.ini'),'head')
        app=create_app(Settings.load());store=app.state.store
        with TestClient(app) as c:
            bid=birth(c)
            with ThreadPoolExecutor(max_workers=4) as pool:responses=list(pool.map(lambda _:start(c,bid,'pg-concurrent'),range(4)))
            assert all(r.status_code==202 for r in responses)
            runs={r.json()['data']['run_id'] for r in responses};assert len(runs)==1
            rid=runs.pop()
            with ThreadPoolExecutor(max_workers=4) as pool:assert sum(pool.map(lambda _:process_one(store,rid),range(4)))==1
            data=c.get('/v1/determinations/'+rid,headers=A).json()['data']
            assert data['terminal']['exact_code']=='INPUT / CHART UNRESOLVED'
            assert start(c,bid,'pg-concurrent').json()['data']==data
            assert c.get('/v1/determinations/'+rid,headers=B).status_code==404
            for model,n in [(Outcome,1),(Stage,2),(Outbox,1),(Job,1),(Audit,3)]:
                with store.session() as s:assert s.scalar(select(func.count()).select_from(model))==n
            with store.engine.begin() as conn:
                with pytest.raises(DatabaseError):conn.execute(text("UPDATE outcomes SET payload='{}' WHERE run_id=:id"),{'id':rid})
            with store.engine.begin() as conn:
                with pytest.raises(IntegrityError):conn.execute(text("INSERT INTO runs(id,owner_id,birth_id,release_id,key_hash,request_digest,created_at) SELECT 'bad','missing-owner',birth_id,release_id,'bad','bad',created_at FROM runs LIMIT 1"))
            assert c.delete('/v1/account',headers=A).status_code==200
            assert c.get('/v1/history',headers=A).status_code==401
        store.engine.dispose()
    finally:
        with admin.begin() as conn:conn.execute(text(f'DROP SCHEMA {schema} CASCADE'))
        admin.dispose()
