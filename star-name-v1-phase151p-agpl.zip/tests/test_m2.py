import json,os,sys,time,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import pytest
from sqlalchemy import select,text,func,event
from sqlalchemy.exc import DatabaseError,IntegrityError
from cryptography.fernet import Fernet
from alembic import command
from alembic.config import Config
from persistence.models import BirthInput,Run,Stage,Outcome,Job,Audit,Outbox,VaultEntry,Redaction
from persistence.db import Store
from persistence.rotation import rotate_batch
from worker.jobs import process_one
from api.config import Settings
from tests.test_m1 import A,B,BIRTH,birth,start,run

def test_redaction_erases_vault_revokes_and_retains_history(local):
    c,store=local;bid,rid=run(c,store);process_one(store,rid)
    before=c.get('/v1/determinations/'+rid,headers=A).json()['data']
    assert c.delete('/v1/account',headers=B).status_code==200
    assert c.get('/v1/determinations/'+rid,headers=A).json()['data']==before
    assert c.delete('/v1/account',headers=A).status_code==200
    for path in ['/v1/history','/v1/birth-inputs','/v1/birth-inputs/'+bid,'/v1/determinations/'+rid]:
        assert c.get(path,headers=A).status_code==401
    assert c.post('/v1/birth-inputs',json=BIRTH,headers=A).status_code==401
    with store.session() as s:
        assert s.scalar(select(func.count()).select_from(VaultEntry))==0
        assert s.get(Outcome,rid).payload==json.dumps(before['terminal'],sort_keys=True)
        assert s.get(BirthInput,bid).encrypted=='VAULT_SEPARATED_M2'
        assert s.scalar(select(func.count()).select_from(Stage))==2
        assert s.scalar(select(func.count()).select_from(Outbox))==1
    with store.engine.begin() as conn:
        with pytest.raises(DatabaseError):conn.execute(text("DELETE FROM account_redactions"))

def test_pending_redaction_keeps_honest_execution(local):
    c,s=local;bid,rid=run(c,s);assert c.delete('/v1/account',headers=A).status_code==200
    assert process_one(s,rid)
    with s.session() as session:assert json.loads(session.get(Outcome,rid).payload)['exact_code']=='INPUT / CHART UNRESOLVED'

def test_privacy_minimization_and_errors(local):
    c,s=local;bid,rid=run(c,s)
    for path in ['/health','/docs','/openapi.json','/v1/history','/v1/birth-inputs']:
        response=c.get(path,headers=A)
        assert BIRTH['place_query_or_selected_ref'] not in response.text
        assert 'local_date' not in response.text
        assert 'owner-a' not in response.text
        assert response.headers['referrer-policy']=='no-referrer'
    invalid=c.post('/v1/birth-inputs',json={**BIRTH,'local_date':'PRIVATE-INVALID-DATE'},headers=A)
    assert 'PRIVATE-INVALID-DATE' not in invalid.text
    assert s.engine.hide_parameters
    assert c.get('/v1/history?cursor='+rid,headers=B).status_code==404

def test_semantic_audit_unique_and_transactional_retry(local):
    c,store=local;bid,rid=run(c,store)
    from sqlalchemy.orm import Session
    def fail(session):
        session.flush()
        raise RuntimeError('synthetic precommit crash')
    event.listen(Session,'before_commit',fail)
    try:
        with pytest.raises(RuntimeError):process_one(store,rid)
    finally:event.remove(Session,'before_commit',fail)
    with store.session() as s:
        assert s.get(Outcome,rid) is None
        assert s.scalar(select(func.count()).select_from(Stage))==0
        assert s.scalar(select(func.count()).select_from(Outbox))==0
        assert s.scalar(select(func.count()).select_from(Audit).where(Audit.object_id==rid))==1
    assert process_one(store,rid)
    assert not process_one(store,rid)
    with store.engine.begin() as conn:
        with pytest.raises(IntegrityError):conn.execute(text("INSERT INTO audit_events(id,object_id,action,created_at) SELECT 'duplicate',object_id,action,created_at FROM audit_events WHERE object_id=:r LIMIT 1"),{'r':rid})

def test_actual_worker_kill_and_restart(local,tmp_path):
    c,store=local;bid,rid=run(c,store);marker=tmp_path/'ready'
    code="""import os,time
from sqlalchemy import event
from sqlalchemy.orm import Session
from api.config import Settings
from persistence.db import Store
from worker.jobs import process_one
@event.listens_for(Session,'before_commit')
def pause(session):
 session.flush()
 open(os.environ['CRASH_MARKER'],'w').write('uncommitted')
 time.sleep(30)
process_one(Store(Settings.load()),os.environ['CRASH_RUN'])
"""
    p=subprocess.Popen([sys.executable,'-c',code],env={**os.environ,'CRASH_MARKER':str(marker),'CRASH_RUN':rid},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
        deadline=time.monotonic()+10
        while not marker.exists() and p.poll() is None and time.monotonic()<deadline:time.sleep(.02)
        assert marker.exists(),p.communicate(timeout=1)
        p.kill();p.wait(timeout=5)
        with store.session() as s:
            assert s.get(Outcome,rid) is None
            assert s.scalar(select(func.count()).select_from(Stage))==0
            assert s.scalar(select(func.count()).select_from(Outbox))==0
        assert process_one(Store(Settings.load()),rid)
        assert c.get('/v1/determinations/'+rid,headers=A).json()['data']['terminal']['exact_code']=='INPUT / CHART UNRESOLVED'
    finally:
        if p.poll() is None:p.kill();p.wait(timeout=5)

def test_key_rotation_and_missing_old_key(local):
    c,s=local;bid=birth(c);settings=Settings.load();new=Fernet.generate_key().decode()
    changed=replace(settings,vault_key=new,key_version='v2',vault_keys={'v1':settings.vault_key,'v2':new})
    next_store=Store(changed)
    with s.session() as session:
        entry=session.get(VaultEntry,bid);assert entry.key_version=='v1';original=entry.ciphertext
    assert rotate_batch(next_store)==1
    assert rotate_batch(next_store)==0
    with next_store.session() as session:
        entry=session.get(VaultEntry,bid);assert entry.key_version=='v2' and entry.ciphertext!=original
        assert json.loads(next_store.decrypt(entry))==BIRTH
    with s.session() as session:
        with pytest.raises(KeyError):s.decrypt(session.get(VaultEntry,bid))
    assert c.delete('/v1/account',headers=A).status_code==200

def test_legacy_database_upgrade_preserves_history(tmp_path,monkeypatch):
    for k,v in {'APP_ENV':'development','DEV_AUTH':'true','DEV_TOKENS':'a'*32+':legacy-owner','VAULT_KEY':Fernet.generate_key().decode(),'ALLOW_DEV_SQLITE':'true','DATABASE_URL':'sqlite:///'+str(tmp_path/'legacy.db')}.items():monkeypatch.setenv(k,v)
    command.upgrade(Config('alembic.ini'),'0001')
    from sqlalchemy import create_engine
    engine=create_engine(os.environ['DATABASE_URL']);key=Fernet.generate_key();cipher=Fernet(key).encrypt(json.dumps(BIRTH).encode()).decode()
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(id) VALUES ('legacy-owner')"))
        conn.execute(text("INSERT INTO birth_inputs(id,owner_id,logical_id,revision,encrypted,created_at) VALUES ('legacy-birth','legacy-owner','legacy-logical',1,:c,'legacy-time')"),{'c':cipher})
    command.upgrade(Config('alembic.ini'),'head')
    with engine.connect() as conn:
        row=conn.execute(text('SELECT ciphertext,key_version FROM birth_vault')).one()
        assert json.loads(Fernet(key).decrypt(row[0].encode()))==BIRTH and row[1]=='v1'
        assert conn.execute(text('SELECT encrypted FROM birth_inputs')).scalar()=='VAULT_SEPARATED_M2'
        assert conn.execute(text('SELECT version_num FROM alembic_version')).scalar()=='0003'

def test_account_redaction_racing_submission(local):
    c,s=local;bid=birth(c)
    with ThreadPoolExecutor(max_workers=2) as pool:
        f1=pool.submit(start,c,bid,'redaction-race');f2=pool.submit(c.delete,'/v1/account',headers=A)
        assert f1.result().status_code in [202,401]
        assert f2.result().status_code==200
    with s.session() as session:
        assert session.scalar(select(func.count()).select_from(VaultEntry))==0
        assert session.get(Redaction,'owner-a')
    assert start(c,bid,'after-redaction').status_code==401

@pytest.mark.parametrize('environment',['production','staging','test',''])
def test_all_non_dev_startup_closed(monkeypatch,environment):
    monkeypatch.setenv('APP_ENV',environment)
    with pytest.raises(RuntimeError):Settings.load()

def test_missing_secret_and_bad_ring_closed(local,monkeypatch):
    monkeypatch.delenv('VAULT_KEY')
    with pytest.raises(KeyError):Settings.load()
    monkeypatch.setenv('VAULT_KEY',Fernet.generate_key().decode());monkeypatch.setenv('VAULT_PREVIOUS_KEYS','{"v0":"invalid"}')
    with pytest.raises(Exception):Settings.load()

def test_backup_restore_reapplies_deletion_ledger(local,tmp_path):
    import sqlite3
    from persistence.privacy import export_tombstones,reapply_tombstones
    c,s=local;bid,rid=run(c,s);process_one(s,rid)
    backup=tmp_path/'backup.db'
    source=sqlite3.connect(s.engine.url.database);dest=sqlite3.connect(backup)
    source.backup(dest);source.close();dest.close()
    assert c.delete('/v1/account',headers=A).status_code==200
    ledger=export_tombstones(s);assert len(ledger)==1
    restored=Store(replace(Settings.load(),database_url='sqlite:///'+str(backup)))
    with restored.session() as session:assert session.get(VaultEntry,bid)
    reapply_tombstones(restored,ledger);reapply_tombstones(restored,ledger)
    with restored.session() as session:
        assert session.get(VaultEntry,bid) is None
        assert session.get(Redaction,'owner-a')
        assert session.get(Outcome,rid)
        assert session.scalar(select(func.count()).select_from(Audit).where(Audit.action=='ACCOUNT_PRIVATE_DATA_REDACTED'))==1

def test_programmatic_settings_cannot_bypass_production(local,monkeypatch):
    settings=Settings.load();monkeypatch.setenv('APP_ENV','production')
    with pytest.raises(RuntimeError):replace(settings)

def test_owner_identifiers_cannot_be_contact_information(local):
    settings=Settings.load()
    with pytest.raises(RuntimeError):replace(settings,dev_tokens={'c'*32:'private@example.invalid'})
