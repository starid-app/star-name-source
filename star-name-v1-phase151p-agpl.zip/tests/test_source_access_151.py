import hashlib,json,zipfile,io
from pathlib import Path
import pytest
from api import source_access as source

def test_anonymous_source_access_release_match_and_notices(local):
    client,store=local
    # A user-private canary proves release download never exports database contents.
    from tests.test_m1 import birth
    birth(client)
    response=client.get('/source/'+source.ARCHIVE_NAME)
    assert response.status_code==200
    assert response.headers['X-Source-Release']==source.RELEASE_ID
    assert hashlib.sha256(response.content).hexdigest()==response.headers['X-Source-SHA256']
    z=zipfile.ZipFile(io.BytesIO(response.content))
    names=z.namelist()
    assert 'LICENSE' in names and 'api/source_access.py' in names
    assert 'vendor/pyswisseph-2.10.3.2.tar.gz' in names
    assert not any(n.endswith(('.db','.sqlite','.sqlite3','.log','.pem','.key')) or n=='.env' for n in names)
    assert client.get('/source/license').status_code==200
    assert 'GeoNames' in client.get('/source/notices').text
    assert source.ARCHIVE_NAME in client.get('/source').text
    assert client.get('/source/../../dev.db').status_code==404
    assert client.get('/source/unknown.zip').status_code==404

def test_corruption_missing_and_mismatch_fail_closed(local,tmp_path,monkeypatch):
    client,_=local
    manifest=json.loads((source.ROOT/'compliance/SOURCE_RELEASE_MANIFEST.json').read_text())
    root=tmp_path/'root';(root/'compliance/releases').mkdir(parents=True)
    (root/'compliance/SOURCE_RELEASE_MANIFEST.json').write_text(json.dumps(manifest))
    original_archive=(source.ROOT/'compliance/releases'/source.ARCHIVE_NAME).read_bytes()
    monkeypatch.setattr(source,'ROOT',root)
    assert client.get('/source/'+source.ARCHIVE_NAME).status_code==503
    archive=root/'compliance/releases'/source.ARCHIVE_NAME;archive.write_bytes(b'corrupt')
    assert client.get('/source/'+source.ARCHIVE_NAME).status_code==503
    archive.write_bytes(original_archive)
    # Exact ZIP alone is insufficient when the deployed source tree differs.
    assert client.get('/source/'+source.ARCHIVE_NAME).status_code==503
    archive.unlink();archive.symlink_to(root/'compliance/SOURCE_RELEASE_MANIFEST.json')
    assert client.get('/source/'+source.ARCHIVE_NAME).status_code==503

def test_prominent_source_link_is_outside_authentication():
    text=(source.ROOT/'web/src/main.tsx').read_text()
    assert '<footer>' in text and '/source/star-name-v1-phase151p-agpl.zip' in text
    assert 'GeoNames' in text and 'CC BY 4.0' in text
