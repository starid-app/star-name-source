"""Authenticated resource custody and archival numerical replay; no user admissions."""
import shutil
from datetime import datetime,timezone
import pytest
from determination import e1_restored as e
from determination.m3 import preflight,NumericalChartAdapter,ResolvedPlace,CivilTimeResolution

def test_approved_bytes_present_without_chart_activation():
    assert e.strict_resource_preflight()==e.HASHES
    assert len(preflight().resource_hashes)==2
    assert not preflight().ready

@pytest.mark.parametrize('name',list(e.HASHES))
@pytest.mark.parametrize('fault',['missing','corrupt','symlink'])
def test_each_resource_reauthenticated(tmp_path,name,fault):
    for n in e.HASHES:shutil.copy2(e.EPHE_DIR/n,tmp_path/n)
    path=tmp_path/name
    if fault=='missing':path.unlink()
    elif fault=='corrupt':path.write_bytes(path.read_bytes()+b'X')
    else:
        path.unlink();path.symlink_to(e.EPHE_DIR/name)
    with pytest.raises(ValueError,match='EPHEMERIS_STRICT_FAILURE'):e.strict_resource_preflight(tmp_path)

def test_runtime_toggle_and_forged_resolution_cannot_activate():
    result=NumericalChartAdapter().calculate(CivilTimeResolution(status='RESOLVED',utc_instant='2026-01-15T12:00:00Z'),ResolvedPlace(status='RESOLVED',latitude='0',longitude='0'))
    assert result['chart'] is None and result['provenance'] is None

def test_runtime_package_mismatch_rejected(monkeypatch):
    pytest.importorskip('swisseph')
    monkeypatch.setattr(e.metadata,'version',lambda _: '99.0')
    with pytest.raises(ValueError,match='runtime identity'):e.require_runtime()

def test_restored_frozen_chart_fingerprint():
    pytest.importorskip('swisseph')
    from determination.historical_rc3.astro.models import ValidatedBirthInput
    v=ValidatedBirthInput(datetime(2026,1,15,12),'UTC',datetime(2026,1,15,12,tzinfo=timezone.utc),0,0,0,0)
    a=e.historical_numerical_regression(v);b=e.historical_numerical_regression(v)
    assert a.chart_fingerprint==b.chart_fingerprint=='sha256:958acc5217dd3b56447adb7eb65d2298d5c4666f46b6eb4c4718068775ab1bd2'

@pytest.mark.parametrize('flags',[4,6,3,0,-1])
def test_conflicting_returned_modes_rejected(monkeypatch,flags):
    swe=pytest.importorskip('swisseph')
    from determination.historical_rc3.astro.models import ValidatedBirthInput
    from determination.historical_rc3.astro.swiss import CalculationEnvironmentError
    v=ValidatedBirthInput(datetime(2026,1,15,12),'UTC',datetime(2026,1,15,12,tzinfo=timezone.utc),0,0,0,0)
    monkeypatch.setattr(swe,'calc_ut',lambda *args:((0,0,0,0,0,0),flags))
    with pytest.raises(CalculationEnvironmentError) as exc:e.historical_numerical_regression(v)
    assert exc.value.state.value=='EPHEMERIS_STRICT_FAILURE'
