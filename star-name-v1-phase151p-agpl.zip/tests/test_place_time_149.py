# Phase151P: all date/time fixtures below are synthetic; no owner birth input is published.
import json,subprocess,sys,os
from pathlib import Path
import pytest
from determination import place_time as pt
from determination.m3 import FrozenPlaceResolver,FrozenCivilTimeResolver,evaluate,place_time_numerical_replay,preflight
from governance.frozen import snapshot,can_execute
from worker.jobs import process_one
I={'local_date':'2001-01-15','local_time':'12:00:00','time_precision':'exact','place_query_or_selected_ref':'Ottawa, Ontario, Canada','consent_version':'M1-private-v1'}
A={'Authorization':'Bearer '+'a'*32};B={'Authorization':'Bearer '+'b'*32}
def test_ordinary_city_and_coordinate_custody():
    p=pt.resolve_place(I['place_query_or_selected_ref'])
    assert p['id']=='geonames:6094817' and p['status']=='RESOLVED'
    assert (p['latitude_e7'],p['longitude_e7'])==(454111700,-756981200)
    assert p['datum']=='WGS84' and p['coordinate_basis']=='LOCALITY_REPRESENTATIVE_POINT'
    assert p['accuracy_meters'] is None and p['record_sha256']
    assert p==pt.resolve_place('  OTTAWA , Ontario , Canada ')
    assert p==pt.resolve_place(p['id'])
def test_same_name_different_jurisdictions():
    assert pt.resolve_place('Ottawa, Illinois, United States')['id']=='geonames:4905006'
    assert pt.resolve_place('Ottawa, Ontario, Canada')['id']=='geonames:6094817'
@pytest.mark.parametrize('query,reason',[('Ottawa','PLACE_SPECIFICATION_INSUFFICIENT'),('Ottawa, Canada','PLACE_SPECIFICATION_INSUFFICIENT'),('NeverExists149, Ontario, Canada','PLACE_UNSUPPORTED'),('Ontario, Ontario, Canada','PLACE_UNSUPPORTED'),('Bombay, Maharashtra, India','PLACE_UNSUPPORTED'),('geonames:0','PLACE_UNSUPPORTED')])
def test_no_guessing_or_historical_alias(query,reason):assert pt.resolve_place(query)['reason']==reason

def test_duplicate_full_hierarchy_cannot_rank():
    r=pt.resolve_place(I['place_query_or_selected_ref']);r2={**r,'id':'geonames:999999999'}
    found,reason=pt.candidates(I['place_query_or_selected_ref'],[r,r2]);assert reason=='PLACE_AMBIGUOUS' and len(found)==2
    found,reason=pt.candidates('Ottawa, Ontario, Canada',[{**r,'admin2_name':'A'}, {**r2,'admin2_name':'B'}]);assert reason=='PLACE_AMBIGUOUS'
    found,reason=pt.candidates('Ottawa, B, Ontario, Canada',[{**r,'admin2_name':'A'},{**r2,'admin2_name':'B'}]);assert reason is None and found[0]['id']==r2['id']
@pytest.mark.parametrize('day,good',[('1900-02-29',False),('2000-02-29',True),('2004-02-29',True),('2100-02-29',False),('1800-02-29',False),('2001-1-15',False),('20010115',False),('1582-10-10',False)])
def test_gregorian_validation(day,good):
    if good:assert pt.parse_local({**I,'local_date':day})[0].day==29
    else:
        with pytest.raises(ValueError):pt.parse_local({**I,'local_date':day})
@pytest.mark.parametrize('clock',['24:00:00','23:59:60','12:00','12:00:00Z','12:00:00+00:00','12:00:00.1234567'])
def test_strict_clock_serialization(clock):
    with pytest.raises(ValueError):pt.parse_local({**I,'local_time':clock})
def test_supported_historical_civil_and_provenance():
    p=pt.resolve_place(I['place_query_or_selected_ref']);r=pt.resolve_time(I,p)
    assert r['utc_instant']=='2001-01-15T17:00:00.000000Z' and r['historical_offset_seconds']==-18000
    assert r['dataset_version']=='2026e' and r['tzif_sha256'] and r['dataset_sha256']
    assert r['calendar']=='PROLEPTIC_GREGORIAN' and r['fold_provenance']=='UNIQUE_INSTANT'
@pytest.mark.parametrize('fold,utc',[(None,None),(0,'2024-11-03T05:30:00.000000Z'),(1,'2024-11-03T06:30:00.000000Z')])
def test_fold_explicit_only(fold,utc):
    p=pt.resolve_place(I['place_query_or_selected_ref']);r=pt.resolve_time({**I,'local_date':'2024-11-03','local_time':'01:30:00','civil_fold':fold},p)
    if utc:assert r['utc_instant']==utc and r['fold_provenance']=='USER_EXPLICIT'
    else:assert r['reason']=='DST_FOLD' and r['utc_instant'] is None
@pytest.mark.parametrize('fold',[None,0,1])
def test_gap_never_coerced(fold):
    r=pt.resolve_time({**I,'local_date':'2024-03-10','local_time':'02:30:00','civil_fold':fold},pt.resolve_place(I['place_query_or_selected_ref']))
    assert r['reason']=='DST_GAP' and r['utc_instant'] is None
@pytest.mark.parametrize('day',['1969-12-31','1900-01-01','2027-01-01'])
def test_unsupported_history(day):assert pt.resolve_time({**I,'local_date':day},pt.resolve_place(I['place_query_or_selected_ref']))['reason']=='TIMEZONE_HISTORY_UNSUPPORTED'
def test_unnecessary_fold_and_invalid_fold():
    p=pt.resolve_place(I['place_query_or_selected_ref'])
    assert pt.resolve_time({**I,'civil_fold':1},p)['reason']=='CIVIL_FOLD_INCONSISTENT'
    for f in [True,'0',2,-1]:assert pt.resolve_time({**I,'civil_fold':f},p)['reason']=='CIVIL_FOLD_INVALID'
def test_host_zone_environment_irrelevant(monkeypatch):
    p=pt.resolve_place(I['place_query_or_selected_ref']);a=pt.resolve_time(I,p)
    monkeypatch.setenv('TZ','Pacific/Honolulu');monkeypatch.setenv('PYTHONTZPATH','/does/not/exist')
    assert pt.resolve_time(I,p)==a
@pytest.mark.parametrize('fault',['corrupt','symlink'])
def test_authority_hash_rejection(tmp_path,fault):
    p=tmp_path/'object';p.write_bytes(b'pinned');sha=pt.digest(p.read_bytes())
    if fault=='corrupt':p.write_bytes(b'changed')
    else:q=tmp_path/'link';q.symlink_to(p);p=q
    with pytest.raises(ValueError):pt.checked_bytes(p,sha)
def test_lock_and_place_registry_tampering_fail_closed(tmp_path,monkeypatch):
    from determination import m3
    for n in ['governance/PLACE_AUTHORITY_LOCK.json','governance/CIVIL_TIME_AUTHORITY_LOCK.json','resources/places.json']:
        p=tmp_path/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('{}')
    monkeypatch.setattr(pt,'ROOT',tmp_path)
    assert m3.FrozenPlaceResolver().resolve(I['place_query_or_selected_ref']).reason=='PLACE_AUTHORITY_INTEGRITY_FAILURE'
    assert 'PLACE_TIME_AUTHORITY_INTEGRITY_FAILURE' in preflight().reasons

def test_full_real_integration_replay_and_strict_flags():
    a=place_time_numerical_replay(I);b=place_time_numerical_replay(I)
    assert a==b and a['chart_fingerprint']=='sha256:c125c66d24849f99dec823711d8dabf2fd4696f0a942187c79b1f10952294f91'
    assert len(a['chart']['planets'])==10 and len(a['chart']['angles'])==4
    assert all(f['requested']==258 and f['returned']&7==2 for f in a['requested_returned_flags'])
    assert a['diagnostic_only'] and not a['product_activation'] and not preflight().ready

def test_replay_process_restart():
    code='from determination.m3 import place_time_numerical_replay; import json; print(place_time_numerical_replay('+repr(I)+')["chart_fingerprint"])'
    a=subprocess.check_output([sys.executable,'-c',code],text=True);b=subprocess.check_output([sys.executable,'-c',code],text=True)
    assert a==b and 'c125c66d' in a

def test_named_place_api_worker_private_retry_restart(local):
    from api.main import create_app
    from api.config import Settings
    from fastapi.testclient import TestClient
    c,store=local
    birth=c.post('/v1/birth-inputs',headers=A,json=I).json()['data']['birth_input_id']
    run=c.post('/v1/determinations',headers={**A,'Idempotency-Key':'149-real-city'},json={'birth_input_id':birth}).json()['data']['run_id']
    assert process_one(store,run)
    route='/v1/determinations/'+run+'/chart-provenance';first=c.get(route,headers=A).json()['data']
    assert first['place']['status']=='RESOLVED' and first['civil_time']['utc_instant']=='2001-01-15T17:00:00.000000Z'
    assert first['chart_status']=='NOT_EXECUTED' and first['missing_authority_objects']==['E4_project_specific_applicable_rights_admission_certificate']
    assert c.get(route,headers=B).status_code==404 and not process_one(store,run)
    with TestClient(create_app(Settings.load())) as restarted:assert restarted.get(route,headers=A).json()['data']==first
    out=c.get('/v1/determinations/'+run,headers=A).json()['data']['terminal']
    assert out['exact_code']=='INPUT / CHART UNRESOLVED' and not out['canonical_available']
    for path in snapshot()['capabilities']:assert not can_execute(path,snapshot())

@pytest.mark.parametrize('patch',[{'local_date':'20010115'},{'local_time':'12:00'},{'civil_fold':True},{'civil_fold':'0'}])
def test_api_rejects_noncanonical_input(local,patch):
    c,_=local;assert c.post('/v1/birth-inputs',headers=A,json={**I,**patch}).status_code==422
