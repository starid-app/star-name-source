import json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import pytest
from sqlalchemy import select,text,func
from sqlalchemy.exc import DatabaseError,IntegrityError
from api.config import Settings
from persistence.models import BirthInput,Run,Job,Outcome,Stage,Audit,Outbox
from worker.jobs import process_one
from governance.frozen import STOP,snapshot,can_execute
A={'Authorization':'Bearer '+'a'*32}
B={'Authorization':'Bearer '+'b'*32}
BIRTH={'local_date':'2000-01-02','local_time':'03:04:05','time_precision':'exact','place_query_or_selected_ref':'Synthetic town, test region','consent_version':'M1-private-v1'}
def birth(c,headers=A):return c.post('/v1/birth-inputs',json=BIRTH,headers=headers).json()['data']['birth_input_id']
def start(c,id,key='fresh',headers=A):return c.post('/v1/determinations',json={'birth_input_id':id},headers={**headers,'Idempotency-Key':key})
def run(c,s):
    id=birth(c); response=start(c,id);assert response.status_code==202
    return id,response.json()['data']['run_id']
def test_config_requires_auth(monkeypatch):
    monkeypatch.delenv('DEV_AUTH',raising=False)
    with pytest.raises(RuntimeError):Settings.load()
def test_production_startup_closed(monkeypatch):
    monkeypatch.setenv('APP_ENV','production')
    with pytest.raises(RuntimeError):Settings.load()
def test_sqlite_explicit_opt_in(local,monkeypatch):
    monkeypatch.setenv('ALLOW_DEV_SQLITE','false')
    with pytest.raises(RuntimeError):Settings.load()
def test_migrations(local):
    c,s=local
    with s.engine.connect() as conn:
        assert conn.execute(text('select version_num from alembic_version')).scalar()=='0003'
        assert len(conn.execute(text("select name from sqlite_master where type='trigger'")).all())==18
def test_input_encrypted_and_immutable(local):
    c,s=local;id=birth(c)
    with s.session() as session:
        b=session.get(BirthInput,id); assert BIRTH['place_query_or_selected_ref'] not in b.encrypted
        b.revision=2
        with pytest.raises(ValueError):session.commit()
    with s.engine.begin() as conn:
        with pytest.raises(DatabaseError):conn.execute(text('update birth_inputs set revision=2 where id=:id'),{'id':id})
def test_raw_sql_delete_blocked(local):
    c,s=local;id=birth(c)
    with s.engine.begin() as conn:
        with pytest.raises(DatabaseError):conn.execute(text('delete from birth_inputs where id=:id'),{'id':id})
def test_owner_isolation(local):
    c,s=local;id,r=run(c,s)
    assert c.get('/v1/birth-inputs/'+id,headers=B).status_code==404
    assert start(c,id,headers=B).status_code==404
    assert c.get('/v1/determinations/'+r,headers=B).status_code==404
    assert c.get('/v1/determinations/'+r+'/canonical',headers=B).status_code==404
    assert c.get('/v1/history',headers=B).json()['data']['items']==[]
def test_unauthenticated(local):
    c,s=local
    assert c.get('/v1/history').status_code==401
    assert c.post('/v1/birth-inputs',json=BIRTH).status_code==401
def test_idempotency_and_conflict(local):
    c,s=local;id,r=run(c,s)
    assert start(c,id).json()['data']['run_id']==r
    other=birth(c);assert start(c,other).status_code==409
    with s.session() as session: assert session.scalar(select(func.count()).select_from(Run))==1
def test_concurrent_idempotency(local):
    c,s=local;id=birth(c)
    with ThreadPoolExecutor(max_workers=4) as pool:responses=list(pool.map(lambda _:start(c,id,'concurrent'),range(4)))
    assert all(x.status_code==202 for x in responses)
    assert len({x.json()['data']['run_id'] for x in responses})==1
def test_exact_stop_retry_refresh_history(local):
    c,s=local;id,r=run(c,s)
    assert process_one(s,r)
    first=c.get('/v1/determinations/'+r,headers=A).json()['data']
    assert first['terminal']['exact_code']==STOP
    assert first['delivery_status']=='FINALIZED'
    assert len(first['executed_stages'])==2
    assert first['not_executed_stages']==list(range(2,31))
    assert not process_one(s,r)
    assert c.get('/v1/determinations/'+r,headers=A).json()['data']==first
    assert start(c,id).json()['data']==first
    assert c.get('/v1/history',headers=A).json()['data']['items']==[first]
    for model in [Outcome,Job,Outbox]:
        with s.session() as session:assert session.scalar(select(func.count()).select_from(model))==1
def test_duplicate_job_delivery(local):
    c,s=local;id,r=run(c,s);process_one(s,r)
    with s.session() as session:job=session.scalar(select(Job));job.state='QUEUED';session.commit()
    assert process_one(s,r)
    with s.session() as session:
        assert session.scalar(select(func.count()).select_from(Stage))==2
        assert session.scalar(select(func.count()).select_from(Outbox))==1
def test_worker_concurrency(local):
    c,s=local;id,r=run(c,s)
    with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(lambda _:process_one(s,r),range(4)))
    assert sum(results)==1
def test_worker_failure_rollback(local,monkeypatch):
    c,s=local;id,r=run(c,s)
    import worker.jobs as jobs
    original=jobs.guard
    def failure(release,input=None):raise RuntimeError('synthetic operational failure')
    monkeypatch.setattr(jobs,'guard',failure)
    with pytest.raises(RuntimeError):process_one(s,r)
    assert c.get('/v1/determinations/'+r,headers=A).json()['data']['delivery_status']=='QUEUED'
    monkeypatch.setattr(jobs,'guard',original);assert process_one(s,r)
def test_disabled_fields_rejected(local):
    c,s=local;id=birth(c)
    for field,value in [('capabilities',{'numerical_chart':True}),('canonical_surname','demo'),('chart_id','fake'),('owner_id','owner-b'),('expression',{'selection':'demo'})]:
        response=c.post('/v1/determinations',json={'birth_input_id':id,field:value},headers={**A,'Idempotency-Key':'bypass'})
        assert response.status_code==422
    assert c.post('/v1/admin/releases',json={'enabled':True},headers=A).status_code==404
def test_env_cannot_activate(local,monkeypatch):
    monkeypatch.setenv('NUMERICAL_CHART_ENABLED','true');monkeypatch.setenv('CANONICAL_ISSUANCE','true')
    assert not any(snapshot()['capabilities'].values())
    assert not can_execute('numerical_chart',{'capabilities':{'numerical_chart':True}})
    assert not can_execute('invented',{})
def test_no_canonical_identity_fields(local):
    c,s=local;id,r=run(c,s);process_one(s,r)
    response=c.get('/v1/determinations/'+r,headers=A)
    def keys(value):
        if isinstance(value,dict):
            for k,v in value.items():yield k;yield from keys(v)
        elif isinstance(value,list):
            for v in value:yield from keys(v)
    forbidden={'canonical_surname','canonical_identity','starid','twinid','canonical_ref'}
    payload=response.json()['data']
    assert not forbidden.intersection(keys(payload))
    assert c.get('/v1/determinations/'+r+'/canonical',headers=A).status_code==409
    assert c.get('/v1/determinations/'+r+'/starid',headers=A).status_code==409
def test_private_no_store(local):
    c,s=local;assert c.get('/v1/history',headers=A).headers['cache-control']=='no-store'
def test_extra_birth_fields_rejected(local):
    c,s=local;assert c.post('/v1/birth-inputs',json={**BIRTH,'preferred_name':'demo'},headers=A).status_code==422
def test_exact_time_only(local):
    c,s=local;assert c.post('/v1/birth-inputs',json={**BIRTH,'time_precision':'approximate'},headers=A).status_code==422
    assert c.post('/v1/birth-inputs',json={**BIRTH,'local_time':'03:04:05+01:00'},headers=A).status_code==422
def test_history_pagination(local):
    c,s=local
    for i in range(3):start(c,birth(c),str(i))
    a=c.get('/v1/history?limit=2',headers=A).json()['data']
    b=c.get('/v1/history?limit=2&cursor='+a['next_cursor'],headers=A).json()['data']
    assert len(a['items'])==2 and len(b['items'])==1
    assert not {x['run_id'] for x in a['items']}.intersection(x['run_id'] for x in b['items'])
def test_expression_component_boundary():
    root=Path(__file__).parents[1]
    for file in (root/'web/src').glob('*'):
        assert 'determination/' not in file.read_text() and 'governance/' not in file.read_text()
    for file in (root/'determination').glob('*.py'):
        assert 'web' not in file.read_text() and 'react' not in file.read_text()
def test_sql_compound_owner_foreign_key(local):
    c,s=local;id,r=run(c,s);birth(c,B)
    with s.engine.begin() as conn:
        with pytest.raises(IntegrityError):
            conn.execute(text("insert into runs(id,owner_id,birth_id,release_id,key_hash,request_digest,created_at) select 'bad','owner-b',birth_id,release_id,'bad','bad',created_at from runs limit 1"))

def test_seeded_exact_vocabulary(local):
    from persistence.models import TerminalState,Release
    c,s=local
    with s.session() as session:
        assert session.scalar(select(func.count()).select_from(TerminalState))==15
        assert session.get(TerminalState,STOP)
        assert session.scalar(select(func.count()).select_from(Release))==1
def test_frozen_manifest_tamper_rejected(monkeypatch):
    import governance.frozen as frozen
    monkeypatch.setattr(frozen,'MANIFEST_HASH','bad')
    with pytest.raises(RuntimeError):frozen.snapshot()
def test_historical_outcome_sql_immutable(local):
    c,s=local;id,r=run(c,s);process_one(s,r)
    with s.engine.begin() as conn:
        with pytest.raises(DatabaseError):conn.execute(text("update outcomes set payload='{}' where run_id=:r"),{'r':r})
def test_stage_ordinals_and_provenance(local):
    c,s=local;id,r=run(c,s);process_one(s,r)
    data=c.get('/v1/determinations/'+r,headers=A).json()['data']
    assert [x['ordinal'] for x in data['executed_stages']]==[0,1]
    assert data['terminal']['stage']==1
    assert data['terminal']['additional_blockers'][0]['evaluated'] is False
    assert data['versions']['resources']['swiss_data']=='AUTHENTICATED_PHASE11_E1_BYTES'

def test_postgresql_schema_compiles():
    from sqlalchemy.schema import CreateTable
    from sqlalchemy.dialects import postgresql
    from persistence.models import Base
    for table in Base.metadata.sorted_tables:
        assert str(CreateTable(table).compile(dialect=postgresql.dialect()))
def test_missing_idempotency_key(local):
    c,s=local;id=birth(c)
    assert c.post('/v1/determinations',json={'birth_input_id':id},headers=A).status_code==422
