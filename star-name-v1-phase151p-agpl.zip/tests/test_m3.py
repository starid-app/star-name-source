"""Fresh implementation fixtures, no real chart or methodology success oracle."""
import hashlib,json
from pathlib import Path
import pytest
from sqlalchemy import select,text
from determination.m3 import (authority_lock,preflight,verify_file,reject_returned_flags,
    FrozenPlaceResolver,FrozenCivilTimeResolver,ResolvedPlace,NumericalChartAdapter,evaluate)
from worker.jobs import process_one
from persistence.models import ChartProvenanceVault,Run,Outcome
from governance.frozen import can_execute,snapshot

A={'Authorization':'Bearer '+'a'*32}
B={'Authorization':'Bearer '+'b'*32}
INPUT={'local_date':'2001-02-03','local_time':'04:05:06','time_precision':'exact','place_query_or_selected_ref':'M3 synthetic unresolved place','consent_version':'M1-private-v1'}
def submit(c,key='m3-fresh'):
    birth=c.post('/v1/birth-inputs',headers=A,json=INPUT).json()['data']['birth_input_id']
    run=c.post('/v1/determinations',headers={**A,'Idempotency-Key':key},json={'birth_input_id':birth}).json()['data']['run_id']
    return birth,run

def test_lock_restores_e1_without_activating():
    lock=authority_lock()
    assert not lock['activation'] and len(lock['exact_resource_identities'])==2
    assert lock['authenticated_requirements']['filenames']==['sepl_18.se1','semo_18.se1']
    assert len(lock['authenticated_requirements']['bodies'])==10
    assert lock['authenticated_requirements']['houses']=='Whole Sign'
    assert lock['missing_authority_objects']

def test_no_toggle_or_complete_synthetic_files_can_enable(tmp_path,monkeypatch):
    for n in authority_lock()['authenticated_requirements']['filenames']:(tmp_path/n).write_bytes(b'synthetic unapproved')
    monkeypatch.setenv('ENABLE_NUMERICAL_CHART','true')
    assert not preflight(tmp_path,Path(__file__),2000).ready
    for path in snapshot()['capabilities']:assert not can_execute(path,{'capabilities':{path:True}})

def test_lock_tampering_fails_closed(tmp_path,monkeypatch):
    import determination.m3 as m3
    p=tmp_path/'lock.json';p.write_text(json.dumps({'activation':True}))
    monkeypatch.setattr(m3,'LOCK_PATH',p)
    with pytest.raises(RuntimeError):preflight()

@pytest.mark.parametrize('condition',['valid_bytes','missing','wrong_hash','corrupt','symlink','absent_hash'])
def test_resource_byte_verifier(tmp_path,condition):
    # These bytes/digests only exercise custody mechanics, never approved ephemeris.
    p=tmp_path/'sepl_18.se1';p.write_bytes(b'fresh synthetic verifier bytes')
    expected=hashlib.sha256(p.read_bytes()).hexdigest()
    if condition=='missing':p.unlink()
    if condition=='wrong_hash':expected='0'*64
    if condition=='corrupt':p.write_bytes(b'corruption')
    if condition=='absent_hash':expected=None
    if condition=='symlink':
        q=tmp_path/'link';q.symlink_to(p);p=q
    result=verify_file(p,expected)
    assert (result is None)==(condition=='valid_bytes')
    assert not preflight(tmp_path).ready

@pytest.mark.parametrize('returned,accepted',[(2,True),(6,False),(4,False),(0,False),(-1,False),(258,True)])
def test_flag_fallback_rejection(returned,accepted):
    # Synthetic masks, not a frozen Swiss flag assignment.
    if accepted:reject_returned_flags(returned,2,4,2)
    else:
        with pytest.raises(ValueError,match='EPHEMERIS_STRICT_FAILURE'):reject_returned_flags(returned,2,4,2)

@pytest.mark.parametrize('year,in_range',[(1799,False),(1800,True),(2399,True),(2400,False)])
def test_ephemeris_range_boundaries(year,in_range):
    pf=preflight(year=year)
    assert ('EPHEMERIS_DATE_OUT_OF_RANGE' not in pf.reasons)==in_range
    assert not pf.ready

@pytest.mark.parametrize('day,clock,case',[('2001-02-03','04:05:06','ordinary'),('2024-11-03','01:30:00','potential_fold'),('2024-03-10','02:30:00','potential_gap'),('1800-01-01','00:00:00','unsupported_history')])
def test_unadmitted_place_prevents_all_interpretations(day,clock,case):
    # No actual zone is assigned to these synthetic transport cases.
    result=FrozenCivilTimeResolver().resolve({**INPUT,'local_date':day,'local_time':clock},ResolvedPlace())
    assert result.status=='UNRESOLVED' and result.utc_instant is None
    assert result.reason=='PLACE_NOT_ADMITTED'

@pytest.mark.parametrize('change,reason',[({'time_precision':'approximate'},'INPUT_PRECISION_INSUFFICIENT'),({'local_time':'12:00:00+01:00'},'LOCAL_CIVIL_TIME_REQUIRED'),({'local_date':'bad'},'CIVIL_INPUT_INVALID'),({'local_date':'1799-01-01'},'EPHEMERIS_DATE_OUT_OF_RANGE')])
def test_civil_input_rejections(change,reason):
    assert FrozenCivilTimeResolver().resolve({**INPUT,**change},ResolvedPlace()).reason==reason

def test_unresolved_place_and_adapter_never_fabricate():
    place=FrozenPlaceResolver().resolve('ambiguous / arbitrary')
    assert place.latitude is None and place.longitude is None and place.resolved_place_id is None
    civil=FrozenCivilTimeResolver().resolve(INPUT,place)
    result=NumericalChartAdapter().calculate(civil,place)
    assert result['chart'] is None and result['provenance'] is None
    assert evaluate(INPUT)==evaluate(INPUT)

def test_provenance_owner_isolation_retry_and_redaction(local):
    c,store=local;birth,run=submit(c)
    assert process_one(store,run)
    route='/v1/determinations/'+run+'/chart-provenance'
    assert c.get(route,headers=B).status_code==404
    assert c.get(route).status_code==401
    first=c.get(route,headers=A).json()['data']
    assert first['birth_input_revision_ref']==birth
    assert first['chart_status']=='NOT_EXECUTED' and first['civil_time']['utc_instant'] is None
    assert not process_one(store,run)
    assert c.get(route,headers=A).json()['data']==first
    with store.session() as s:
        row=s.get(ChartProvenanceVault,run)
        assert 'UNRESOLVED' not in row.ciphertext
        assert len(list(s.scalars(select(ChartProvenanceVault))))==1
    assert c.delete('/v1/account',headers=A).status_code==200
    with store.session() as s:
        assert s.get(ChartProvenanceVault,run) is None
        assert s.get(Outcome,run) is not None
    assert c.get(route,headers=A).status_code==401

def test_deleted_queued_input_never_reconstructed(local):
    c,store=local;birth,run=submit(c)
    assert c.delete('/v1/account',headers=A).status_code==200
    assert process_one(store,run)
    with store.session() as s:
        assert s.get(ChartProvenanceVault,run) is None
        assert json.loads(s.get(Outcome,run).payload)['exact_code']=='INPUT / CHART UNRESOLVED'

def test_provenance_rotation_and_restore_gate(local):
    from cryptography.fernet import Fernet
    from persistence.rotation import rotate_batch
    from persistence.privacy import reapply_tombstones
    c,store=local;birth,run=submit(c);process_one(store,run)
    with store.session() as s:
        old=store.decrypt(s.get(ChartProvenanceVault,run))
    store.key_version='v2';store.vault=Fernet(Fernet.generate_key());store.keys['v2']=store.vault
    assert rotate_batch(store)==2
    with store.session() as s:
        entry=s.get(ChartProvenanceVault,run)
        assert entry.key_version=='v2' and store.decrypt(entry)==old
    reapply_tombstones(store,[{'owner_id':'owner-a','created_at':'synthetic-deletion'}])
    with store.session() as s:assert s.get(ChartProvenanceVault,run) is None

def test_provenance_transaction_rollback(local,monkeypatch):
    import worker.jobs as jobs
    c,store=local;birth,run=submit(c)
    original=jobs.guard
    def failure(*args):raise RuntimeError('fresh injected crash')
    monkeypatch.setattr(jobs,'guard',failure)
    with pytest.raises(RuntimeError):process_one(store,run)
    with store.session() as s:assert s.get(ChartProvenanceVault,run) is None
    monkeypatch.setattr(jobs,'guard',original)
    assert process_one(store,run)
